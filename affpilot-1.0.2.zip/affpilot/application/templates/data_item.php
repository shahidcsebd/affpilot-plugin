<?php
defined('\ABSPATH') || exit;

use AffPilot\application\helpers\TemplateHelper;

if (TemplateHelper::isModuleDataExist($items, 'Amazon', 'AmazonNoApi'))
    \wp_enqueue_script('affpilot-frontend', \AffPilot\PLUGIN_RES . '/js/frontend.js', array('jquery'));
?>

<?php if ($title): ?>
    <h3 class="affpilot-shortcode-title"><?php echo \esc_html($title); ?></h3>
<?php endif; ?>
<?php foreach ($items as $item): ?>

    <div class="affpilot-container affpilot-item">
        <div class="products">

            <?php $this->renderBlock('item_row', array('item' => $item)); ?>

            <div class="row">
                <div class="col-md-12">
                    <div class="affpilot-mb25">
                        <?php $this->renderPartialModule('_item_details_top', array('Flipkart'), array('item' => $item)); ?>                            
                        <?php $this->renderBlock('item_features', array('item' => $item)); ?>
                        <?php if ($item['description']): ?>
                            <p><?php echo $item['description']; ?></p>
                        <?php endif; ?>                    
                        <?php $this->renderPartialModule('_item_details_bottom', array('Envato', 'Udemy'), array('item' => $item)); ?>                            
                        <?php $this->renderBlock('item_reviews', array('item' => $item)); ?>
                    </div>
                </div>
            </div>    
        </div>
    </div>
<?php endforeach; ?>