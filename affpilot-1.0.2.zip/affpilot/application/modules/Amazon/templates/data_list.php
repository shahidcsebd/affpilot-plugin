<?php

defined('\ABSPATH') || exit;

/*
  Name: List
 */
__('List', 'affpilot-tpl');

$this->renderPartial('list');
