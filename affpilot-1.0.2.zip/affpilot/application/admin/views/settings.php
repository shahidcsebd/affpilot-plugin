<?php defined('\ABSPATH') || exit; ?>

<?php if (\AffPilot\application\Plugin::isFree() || \AffPilot\application\Plugin::isInactiveEnvato()): ?>
    <div class="affpilot-maincol">
    <?php endif; ?>
    <div class="wrap">
        <h2>
            <?php _e('Affpilot Settings', 'affpilot'); ?>
            <?php if (\AffPilot\application\Plugin::isPro()): ?>
            <span class="affpilot-label affpilot-label-pro">pro <small><?php echo \AffPilot\application\Plugin::version(); ?></small></span>
            <?php else: ?>
                <a target="_blank" class="page-title-action" href="<?php echo \AffPilot\application\Plugin::pluginSiteUrl(); ?>">Go PRO</a>                
            <?php endif; ?>
        </h2>

        <?php \settings_errors(); ?>   
        <form action="options.php" method="POST">
            <?php \settings_fields($page_slug); ?>
            <?php \AffPilot\application\helpers\AdminHelper::doTabsSections($page_slug); ?>
            <?php \submit_button(); ?>
        </form>
    </div>

    <?php if (\AffPilot\application\Plugin::isFree() || \AffPilot\application\Plugin::isInactiveEnvato()): ?>
    </div>    
    <?php include('_promo_box.php'); ?>
<?php endif; ?>