<?php
defined('\ABSPATH') || exit;

use AffPilot\application\helpers\TemplateHelper;
?>

<div class="row">
    <div class="col-md-6 text-center affpilot-image-container affpilot-mb20">
        <?php if ($item['img']): ?>
            <a<?php TemplateHelper::printRel(); ?> target="_blank" href="<?php echo $item['url']; ?>">      
                <?php TemplateHelper::displayImage($item, 350, 350); ?>
            </a>
        <?php endif; ?>
    </div>
    <div class="col-md-6">
        <?php if ($item['title']): ?>
            <h3 class="affpilot-item-title"><?php echo $item['title']; ?></h3>
        <?php endif; ?>
        <?php if ($item['rating']): ?>
            <div class="affpilot-mb5">
                <?php echo TemplateHelper::printRating($item, 'default'); ?>
            </div>
        <?php endif; ?>

        <div class="affpilot-price-row">

            <?php if ($item['price']): ?>
                <span class="affpilot-price affpilot-price-color">            
                    <?php if ($item['priceOld']): ?>
                        <span class="text-muted"><strike><?php echo TemplateHelper::formatPriceCurrency($item['priceOld'], $item['currencyCode'], '<small>', '</small>'); ?></strike></span><br>
                    <?php endif; ?>
                            <?php echo TemplateHelper::formatPriceCurrency($item['price'], $item['currencyCode'], '<span class="affpilot-currency">', '</span>'); ?></span>
                    <?php endif; ?>


            <?php if ($stock_status = TemplateHelper::getStockStatusStr($item)): ?>
                <mark title="<?php echo \esc_attr(sprintf(TemplateHelper::__('Last updated on %s'), TemplateHelper::getLastUpdateFormatted($module_id, $post_id))); ?>" class="stock-status status-<?php echo \esc_attr(TemplateHelper::getStockStatusClass($item)); ?>">
                    &nbsp;<?php echo \esc_html($stock_status); ?>
                </mark>
            <?php endif; ?>            
            <?php if ($cashback_str = TemplateHelper::getCashbackStr($item)): ?>
                <div class="affpilot-cashback"><?php echo sprintf(TemplateHelper::__('Plus %s Cash Back'), $cashback_str); ?></div>                            
            <?php endif; ?>
        </div>

        <?php $this->renderBlock('item_after_price_row', array('item' => $item)); ?>

        <div class="affpilot-btn-row affpilot-mb5">
            <div><a<?php TemplateHelper::printRel(); ?> target="_blank" href="<?php echo $item['url']; ?>" class="btn btn-danger affpilot-btn-big"><?php TemplateHelper::buyNowBtnText(true, $item, $btn_text); ?></a></div>
            <span class="title-case text-muted">
                <?php TemplateHelper::getMerhantName($item, true); ?>
                <?php TemplateHelper::printShopInfo($item, array('data-placement' => 'bottom')); ?>

            </span>
        </div>
        <div class="affpilot-last-update-row affpilot-mb15">
            <span class="text-muted">
                <small>
                    <?php echo sprintf(TemplateHelper::__('as of %s'), TemplateHelper::getLastUpdateFormatted($module_id, $post_id)); ?>
                    <?php if ($module_id == 'Amazon' || $module_id == 'AmazonNoApi') TemplateHelper::printAmazonDisclaimer(); ?>
                </small>
            </span>                    
        </div>
    </div>
</div>

