<?php

namespace AffPilot\application\modules\Amazon;

defined('\ABSPATH') || exit;

use AffPilot\application\components\AffiliateParserModuleConfig;
use AffPilot\application\libs\amazon\AmazonLocales;

/**
 * AmazonConfig class file
 *
 * @author keywordrush.com <support@keywordrush.com>
 * @link https://www.keywordrush.com
 * @copyright Copyright &copy; 2021 keywordrush.com
 */
class AmazonConfig extends AffiliateParserModuleConfig {

    public function options()
    {
        $options = array(
            'access_key_id' => array(
                'title' => 'Access Key <span class="cegg_required">*</span>',
                'description' => sprintf(__('To get access key and API <a target="_blank" href="%s">Signup for PA API</a>.', 'affpilot'), 'https://webservices.amazon.com/paapi5/documentation/register-for-pa-api.html'),
                'callback' => array($this, 'render_input'),
                'default' => '',
                'validator' => array(
                    'trim',
                    array(
                        'call' => array('\AffPilot\application\helpers\FormValidator', 'required'),
                        'when' => 'is_active',
                        'message' => __('The "Access Key" can not be empty', 'affpilot'),
                    ),
                ),
                'section' => 'default',
            ),
            'secret_access_key' => array(
                'title' => 'Secret Key <span class="cegg_required">*</span>',
                'description' => sprintf(__('To get secret key and API <a target="_blank" href="%s">Signup for PA API</a>.', 'affpilot'), 'https://webservices.amazon.com/paapi5/documentation/register-for-pa-api.html'),
                'callback' => array($this, 'render_input'),
                'default' => '',
                'validator' => array(
                    'trim',
                    array(
                        'call' => array('\AffPilot\application\helpers\FormValidator', 'required'),
                        'when' => 'is_active',
                        'message' => __('The "Secret Key" can not be empty.', 'affpilot'),
                    ),
                    array(
                        'call' => array('\AffPilot\application\helpers\FormValidator', 'exact_length'),
                        'arg' => 40,
                        'message' => sprintf(__('The field "%s" must have an exact length of value: %d.', 'affpilot'), 'Secret Key', 40),
                    ),
                ),
                'section' => 'default',
            ),
            'associate_tag' => array(
                'title' => __('Tracking ID', 'affpilot') . ' <span class="cegg_required">*</span>',
                'description' => __('Learn more about <a target="_blank" href="https://webservices.amazon.com/paapi5/documentation/troubleshooting/sign-up-as-an-associate.html">Becoming an Associate</a>.', 'affpilot'),
                'callback' => array($this, 'render_input'),
                'default' => '',
                'validator' => array(
                    'trim',
                    array(
                        'call' => array('\AffPilot\application\helpers\FormValidator', 'required'),
                        'when' => 'is_active',
                        'message' => __('The "Tracking ID" can not be empty.', 'affpilot'),
                    ),
                ),
                'section' => 'default',
            ),
            'locale' => array(
                'title' => __('Primary Geography ', 'affpilot') . '<span class="cegg_required">*</span>',
                'description' => __('To become associate in multiple geography you need to signup for each geography separately', 'affpilot'),
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => self::getLocalesList(),
                'default' => self::getDefaultLocale(),
                'section' => 'default',
            ),
            'forced_urls_update' => array(
                'title' => __('Forced links update', 'affpilot'),
                'description' => __('Override/update existing links with new Tracking ID.', 'affpilot'),
                'callback' => array($this, 'render_checkbox'),
                'default' => false,
                'section' => 'default',
            ),
            'entries_per_page' => array(
                'title' => __('Results', 'affpilot'),
                'description' => __('Number of results for one search query.', 'affpilot') . ' ' .
                __('It needs a bit more time to get more than 10 results in one request', 'affpilot'),
                'callback' => array($this, 'render_input'),
                'default' => 10,
                'validator' => array(
                    'trim',
                    'absint',
                    array(
                        'call' => array('\AffPilot\application\helpers\FormValidator', 'less_than_equal_to'),
                        'arg' => 50,
                        'message' => __('The field "Results" can not be more than 50.', 'affpilot'),
                    ),
                ),
                'section' => 'default',
            ),
            'entries_per_page_update' => array(
                'title' => __('Results for updates', 'affpilot'),
                'description' => __('Number of results for automatic updates and blogging automation.', 'affpilot') . ' ' .
                __('It needs a bit more time to get more than 10 results in one request.', 'affpilot'),
                'callback' => array($this, 'render_input'),
                'default' => 3,
                'validator' => array(
                    'trim',
                    'absint',
                    array(
                        'call' => array('\AffPilot\application\helpers\FormValidator', 'less_than_equal_to'),
                        'arg' => 50,
                        'message' => __('The field "Results" can not be more than 50.', 'affpilot'),
                    ),
                ),
                'section' => 'default',
            ),
            'link_type' => array(
                'title' => __('Link type', 'affpilot'),
                'description' => __('Type of partner links. Know more about amazon <a target="_blank" href="https://affiliate-program.amazon.com/gp/associates/help/t2/a11">90 day cookie</a>.', 'affpilot'),
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => array(
                    'product' => 'Product page',
                    'add_to_cart' => 'Add to cart',
                ),
                'default' => 'product',
                'section' => 'default',
            ),
//            'search_index' => array(
//                'title' => __('Search Index', 'affpilot'),
//                'description' => sprintf(__('Indicates the product category to search. SearchIndex values differ by marketplace. For list of search index values, refer <a target="_blank" href="%s">Locale Reference</a>.', 'affpilot'), 'https://webservices.amazon.com/paapi5/documentation/locale-reference.html'),
//                'callback' => array($this, 'render_input'),
//                'default' => '',
//                'validator' => array(
//                    'trim',
//                ),
//            ),
            'SortBy' => array(
                'title' => __('Sort', 'affpilot'),
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => array(
                    '' => __('Default (recommended)', 'affpilot'),
                    'AvgCustomerReviews' => 'Avg Customer Reviews',
                    'Featured' => 'Featured',
                    'NewestArrivals' => 'Newest Arrivals',
                    'Price:HighToLow' => 'Price: High To Low',
                    'Price:LowToHigh' => 'Price: Low To High',
                    'Relevance' => 'Relevance',
                ),
                'default' => '',
            ),
//            'brouse_node' => array(
//                'title' => __('Browse Node ID', 'affpilot'),
//                'description' => __('A unique ID assigned by Amazon that identifies a product category/sub-category.', 'affpilot'),
//                'callback' => array($this, 'render_input'),
//                'default' => '',
//                'validator' => array(
//                    'trim',
//                ),
//            ),
            'title' => array(
                'title' => __('Search in Title', 'affpilot'),
                'description' => __('Search for product titles only.', 'affpilot'),
                'callback' => array($this, 'render_checkbox'),
                'default' => false,
                'section' => 'default',
            ),
            'Merchant' => array(
                'title' => __('Merchant', 'affpilot'),
                'description' => __('Filters search results to return items having at least one offer sold by target merchant.', 'affpilot'),
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => array(
                    'All' => __('List Offers from all Merchants', 'affpilot'),
                    'Amazon' => __('List Offers only from Amazon', 'affpilot'),
                ),
                'default' => '',
            ),
            'minimum_price' => array(
                'title' => __('Minimal price', 'affpilot'),
                'description' => __('Filters search results to items with at least one offer price above the specified value.', 'affpilot') . ' ' .
                __('For example, 31.41', 'affpilot'),
                'callback' => array($this, 'render_input'),
                'default' => '',
                'validator' => array(
                    'trim',
                ),
            //'metaboxInit' => true,
            ),
            'maximum_price' => array(
                'title' => __('Maximal price', 'affpilot'),
                'description' => __('Filters search results to items with at least one offer price below the specified value.', 'affpilot') . ' ' .
                __('For example, 32.41', 'affpilot'),
                'callback' => array($this, 'render_input'),
                'default' => '',
                'validator' => array(
                    'trim',
                ),
            //'metaboxInit' => true,
            ),
            'min_percentage_off' => array(
                'title' => __('Minimum saving percent', 'affpilot'),
                'description' => __('Filters search results to items with at least one offer having saving percentage above the specified value.', 'affpilot'),
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => array(
                    '' => __('Any', 'affpilot'),
                    '5%' => '5%',
                    '10%' => '10%',
                    '15%' => '15%',
                    '20%' => '20%',
                    '25%' => '25%',
                    '30%' => '30%',
                    '35%' => '35%',
                    '40%' => '40%',
                    '45%' => '45%',
                    '50%' => '50%',
                    '60%' => '60%',
                    '70%' => '70%',
                    '80%' => '80%',
                    '90%' => '90%',
                    '95%' => '95%',
                ),
                'default' => '',
            //'metaboxInit' => true,
            ),
            'Condition' => array(
                'title' => __('Condition', 'affpilot'),
                'description' => __('The condition parameter filters offers by condition type. For example, Condition:Used will return items having atleast one offer of Used condition type.', 'affpilot'),
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => array(
                    '' => __('Any', 'affpilot'),
                    'New' => __('New', 'affpilot'),
                    'Used' => __('Used', 'affpilot'),
                    'Collectible' => __('Collectible', 'affpilot'),
                    'Refurbished' => __('Refurbished', 'affpilot'),
                ),
                'default' => '',
            ),
//            'CurrencyOfPreference' => array(
//                'title' => __('Currency of preference', 'affpilot'),
//                'description' => sprintf(__('Currency of preference in which the prices information should be returned in response. By default the prices are returned in the default currency of the marketplace. Expected currency code format is the ISO 4217 currency code (i.e. USD, EUR etc.). For information on default currency and valid currencies for a marketplace, refer <a target="_blank" href="%s">Locale Reference</a>.', 'affpilot'), 'https://webservices.amazon.com/paapi5/documentation/locale-reference.html#topics'),
//                'callback' => array($this, 'render_input'),
//                'default' => '',
//                'validator' => array(
//                    'trim',
//                ),
//                'default' => '',
//            ),
//            'LanguagesOfPreference' => array(
//                'title' => __('Languages of preference', 'affpilot'),
//                'description' => sprintf(__('Languages in order of preference in which the item information should be returned in response. By default the item information is returned in the default language of the marketplace. Expected locale format is the ISO 639 language code followed by underscore followed by the ISO 3166 country code (i.e. en_US, fr_CA etc.). For information on default language and valid languages for a marketplace, refer <a target="_blank" href="%s">Locale Reference</a>.', 'affpilot'), 'https://webservices.amazon.com/paapi5/documentation/locale-reference.html#topics'),
//                'callback' => array($this, 'render_input'),
//                'default' => '',
//                'validator' => array(
//                    'trim',
//                ),
//                'default' => '',
//            ),
            'AmazonGlobal' => array(
                'title' => __('Amazon Global', 'affpilot'),
                'description' => __('Amazon Global products', 'affpilot')
                . ' <p class="description">' . __('A delivery program featuring international shipping to certain Exportable Countries.', 'affpilot') . '</p>',
                'callback' => array($this, 'render_checkbox'),
                'default' => false,
            ),
            'FreeShipping' => array(
                'title' => __('Free Shipping', 'affpilot'),
                'description' => __('Free Shipping products', 'affpilot')
                . ' <p class="description">' . __('A delivery program featuring free shipping of an item.', 'affpilot') . '</p>',
                'callback' => array($this, 'render_checkbox'),
                'default' => false,
            ),
//            'FulfilledByAmazon' => array(
//                'title' => __('Amazon FBA', 'affpilot'),
//                'description' => __('Amazon FBA', 'affpilot')
//                . ' <p class="description">' . __('Amazon FBA indicates that products are stored, packed and dispatched by Amazon.', 'affpilot') . '</p>',
//                'callback' => array($this, 'render_checkbox'),
//                'default' => false,
//            ),
            'Prime' => array(
                'title' => __('Prime', 'affpilot'),
                'description' => __('Prime products', 'affpilot')
                . ' <p class="description">' . __('An offer for an item which is eligible for Prime Program.', 'affpilot') . '</p>',
                'callback' => array($this, 'render_checkbox'),
                'default' => false,
            ),
            'MinReviewsRating' => array(
                'title' => __('Minimum rating', 'affpilot'),
                'description' => __('Filters search results to items with customer review ratings above specified value.', 'affpilot'),
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => array(
                    '' => __('Any', 'affpilot'),
                    '4.' => 4,
                    '3.' => 3,
                    '2.' => 2,
                    '1.' => 1,
                ),
                'default' => '',
            ),
//            'save_img' => array(
//                'title' => __('Save images', 'affpilot'),
//                'description' => __('Save images to local server', 'affpilot')
//                . ' <p class="description">' . __('Enabling this option may violate API rules.', 'affpilot') . '</p>',
//                'callback' => array($this, 'render_checkbox'),
//                'default' => false,
//                'section' => 'default',
//            ),
//            'show_small_logos' => array(
//                'title' => __('Small logos', 'affpilot'),
//                'callback' => array($this, 'render_dropdown'),
//                'description' => __('Enabling this option may violate API rules.', 'affpilot') . ' '
//                . sprintf(__('Read more: <a target="_blank" href="%s">Amazon brand usage guidelines</a>.', 'affpilot'), 'https://advertising.amazon.com/ad-specs/en/policy/brand-usage'),
//                'dropdown_options' => array(
//                    'true' => __('Show small logos', 'affpilot'),
//                    'false' => __('Hide small logos', 'affpilot'),
//                ),
//                'default' => 'false',
//            ),
//            'show_large_logos' => array(
//                'title' => __('Large logos', 'affpilot'),
//                'callback' => array($this, 'render_dropdown'),
//                'dropdown_options' => array(
//                    'true' => __('Show large logos', 'affpilot'),
//                    'false' => __('Hide large logos', 'affpilot'),
//                ),
//                'default' => 'true',
//            ),
        );

        foreach (self::getLocalesList() as $locale_id => $locale_name)
        {
            $options['associate_tag_' . $locale_id] = array(
                'title' => sprintf(__('Associate Tag for %s locale', 'affpilot'), $locale_name),
                'description' => __('Type here your tracking ID for this locale if you need multiple locale parsing', 'affpilot'),
                'callback' => array($this, 'render_input'),
                'default' => '',
                'validator' => array(
                    'trim',
                ),
            );
        }

        $parent = parent::options();
        $parent['ttl_items']['default'] = 86400;
        $options = array_merge($parent, $options);

        $options['forced_tag'] = array(
            'title' => __('Forced Associate Tag', 'affpilot'),
            'description' => __('Forced replacement of tag parameter in all links. Usually you should leave this field blank!', 'affpilot'),
            'callback' => array($this, 'render_input'),
            'default' => '',
            'validator' => array(
                'trim',
            ),
        );

        return self::moveRequiredUp($options);
    }

    public static function getLocalesList()
    {
        $locales = array_keys(self::locales());
        sort($locales);
        return array_combine($locales, array_map('strtoupper', $locales));
    }

    public static function getDefaultLocale()
    {
        return 'us';
    }

    public static function getActiveLocalesList()
    {
        $locales = self::getLocalesList();
        $active = array();

        $default = self::getInstance()->option('locale');
        $active[$default] = $locales[$default];

        foreach ($locales as $locale => $name)
        {
            if ($locale == $default)
                continue;
            if (self::getInstance()->option('associate_tag_' . $locale))
                $active[$locale] = $name;
        }
        return $active;
    }

    public static function getDomainByLocale($locale)
    {
        return AmazonLocales::getDomain($locale);
    }

    public static function locales()
    {
        return AmazonLocales::locales();
    }

}
