<?php

defined('\ABSPATH') || exit;

/*
  Name: Product card (no features)
 */

__('Product card (no features)', 'affpilot');

$this->renderPartial('item_simple');
