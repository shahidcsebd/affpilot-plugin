<?php
/*
 * Name: Sorted offers list with product images
 * Modules:
 * Module Types: PRODUCT
 * 
 */

__('Sorted offers list with product images', 'affpilot-tpl');

use AffPilot\application\helpers\TemplateHelper;

if (isset($data['Amazon']) || isset($data['AmazonNoApi']))
    \wp_enqueue_script('affpilot-frontend', \AffPilot\PLUGIN_RES . '/js/frontend.js', array('jquery'));

$all_items = TemplateHelper::sortAllByPrice($data, $order, $sort);
$amazon_last_updated = TemplateHelper::getLastUpdateFormattedAmazon($data);
?>

<div class="affpilot-container affpilot-list-withlogos">
    <?php if ($title): ?>
        <h3><?php echo \esc_html($title); ?></h3>
    <?php endif; ?>

    <div class="affpilot-listcontainer">

        <div class="row-products">
            <div class="col-md-3 col-sm-3 col-xs-12 affpilot-title-cell"><span>Product Title</span></div>
            <div class="col-md-1 col-sm-1 col-xs-12 affpilot-image-cell"><span>Image</span></div>
            <div class="col-md-3 col-sm-3 col-xs-12 affpilot-desc-cell hidden-xs"><span>Details</span></div>
            <div class="col-md-3 col-sm-3 col-xs-12 affpilot-price-cell text-center"><span>Price</span></div>
            <div class="col-md-2 col-sm-2 col-xs-12 affpilot-btn-cell"><span>Check Price</span></div>
        </div>

        <?php foreach ($all_items as $key => $item): ?>    
            <?php $this->renderBlock('list_row', array('item' => $item, 'amazon_last_updated' => $amazon_last_updated));?>
        <?php endforeach; ?>
        
    </div>
</div>


