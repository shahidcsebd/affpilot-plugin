<?php

namespace AffPilot\application\components;

defined('\ABSPATH') || exit;

/**
 * ParserModuleConfig abstract class file
 *
 * @author keywordrush.com <support@keywordrush.com>
 * @link http://www.keywordrush.com/
 * @copyright Copyright &copy; 2016 keywordrush.com
 */
abstract class AffiliateParserModuleConfig extends ParserModuleConfig {

    public function options()
    {
        $options = array(
            'ttl' => array(
                'title' => __('Keyword Update Time', 'affpilot'),
                'description' => __('Time in seconds. If you do not want to update products of the keywords, put = 0 here.', 'affpilot'),
                'callback' => array($this, 'render_input'),
                'default' => 2592000,
                'validator' => array(
                    'trim',
                    'absint',
                ),
                'section' => 'default',
            ),
        );
        
        if ($this->getModuleInstance()->isItemsUpdateAvailable())
        {
            $options['ttl_items'] = array(
                'title' => __('Product Price Update', 'affpilot'),
                'description' => __('Time in seconds for updating prices, availability, etc. 0 - never update', 'affpilot'),
                'callback' => array($this, 'render_input'),
                'default' => 604800,
                'validator' => array(
                    'trim',
                    'absint',
                ),
                'section' => 'default',
            );
        }
        $options['update_mode'] = array(
            'title' => __('Update mode', 'affpilot'),
            'description' => '',
            'callback' => array($this, 'render_dropdown'),
            'dropdown_options' => array(
                'visit' => __('Page view', 'affpilot'),
                'cron' => __('Cron', 'affpilot'),
                'visit_cron' => __('Page view + Cron', 'affpilot'),
            ),
            'default' => 'visit',
        );

        return
                array_merge(
                parent::options(), $options
        );
    }



}
