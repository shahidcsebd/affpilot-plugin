<?php

defined('\ABSPATH') || exit;

/*
  Name: Price tracker & alert
 */

__('Price tracker & alert', 'affpilot-tpl');

$this->renderPartial('price_tracker_alert');
