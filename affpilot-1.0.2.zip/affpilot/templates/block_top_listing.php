<?php
/*
 * Name: Top listing
 * Modules:
 * Module Types: PRODUCT
 * 
 */

use AffPilot\application\helpers\TemplateHelper;

$all_items = TemplateHelper::mergeAll($data, $order);
$ratings = TemplateHelper::generateStaticRatings(count($all_items));
?>



<div class="affpilot-container affpilot-top-listing">
    <?php if ($title): ?>
        <h3><?php echo \esc_html($title); ?></h3>
    <?php endif; ?>

    <div class="affpilot-listcontainer">

        <?php foreach ($all_items as $i => $item): ?>    

            <div class="row-products row">
                <div class="col-md-2 col-sm-2 col-xs-3 affpilot-image-cell">

                    <div class="affpilot-position-container2">
                        <span class="affpilot-position-text2"><?php echo (int) $i + 1; ?></span>
                    </div>

                    <?php if ($item['img']): ?>
                        <a<?php TemplateHelper::printRel(); ?> target="_blank" href="<?php echo $item['url']; ?>">
                            <?php TemplateHelper::displayImage($item, 130, 100); ?>
                        </a>
                    <?php endif; ?>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-6 affpilot-desc-cell">

                    <?php if (strstr($item['description'], 'class="label')): ?>
                        <?php echo $item['description']; ?>
                    <?php else: ?>
                        <?php if ($i == 0 && TemplateHelper::getChance($i)): ?>
                            <span class="label label-success">&check; <?php echo __('Best choice', 'affpilot-tpl'); ?></span>
                        <?php elseif ($i == 1 && TemplateHelper::getChance($i)): ?>
                            <span class="label label-success"><?php echo __('Recommended', 'affpilot-tpl'); ?></span>
                        <?php elseif ($i == 2 && TemplateHelper::getChance($i)): ?>
                            <span class="label label-success"><?php echo __('High quality', 'affpilot-tpl'); ?></span>
                        <?php endif; ?>
                    <?php endif; ?>

                    <div class="affpilot-no-top-margin affpilot-list-logo-title">
                        <a<?php TemplateHelper::printRel(); ?> target="_blank" href="<?php echo $item['url']; ?>"><?php echo \esc_html(TemplateHelper::truncate($item['title'], 100)); ?></a>
                    </div>
                    <div class="text-center affpilot-mt10 visible-xs">
                        <a<?php TemplateHelper::printRel(); ?> target="_blank" href="<?php echo $item['url']; ?>" class="btn btn-danger btn-block"><span><?php TemplateHelper::buyNowBtnText(true, $item, $btn_text); ?></span></a> 
                        <?php if ($merchant = TemplateHelper::getMerhantName($item)): ?>
                            <small class="text-muted title-case"><?php echo \esc_html($merchant); ?></small>
                        <?php endif; ?>
                    </div>  
                </div>

                <div class="col-md-2 col-sm-2 col-xs-3">   
                    <?php TemplateHelper::printProgressRing($ratings[$i]); ?>

                </div>                

                <div class="col-md-2 col-sm-2 col-xs-12 affpilot-btn-cell hidden-xs">   
                    <div class="affpilot-btn-row">
                        <a<?php TemplateHelper::printRel(); ?> target="_blank" href="<?php echo $item['url']; ?>" class="btn btn-danger btn-block"><span><?php TemplateHelper::buyNowBtnText(true, $item, $btn_text); ?></span></a> 
                    </div>  
                    <?php if ($merchant = TemplateHelper::getMerhantName($item)): ?>
                        <div class="text-center">
                            <small class="text-muted title-case"><?php echo \esc_html($merchant); ?></small>
                        </div>
                    <?php endif; ?>

                </div>
            </div>



        <?php endforeach; ?>

    </div>
</div>


