<?php

namespace AffPilot;

/*
    Plugin Name: AffPilot
    Plugin URI: https://affpilot.com
    Description: Single window solution for your affiliate marketing business.
    Version: 1.0.2
    Domain Path: languages
    Author: AffPilot Team
    Author URI: https://affpilot.com
    Text Domain: affpilot
	Copyright (c)  affpilot.com
 */

/*
 * Copyright (c)  www.keywordrush.com  (email: support@keywordrush.com)
 */

defined( 'AFFPILOT_AUTHOR_EMAIL' ) | define( 'AFFPILOT_AUTHOR_EMAIL', 'shahid.rangpur@gmail.com' );


add_action( 'wp_head', function () {

	$license_keys = get_option( 'affpilot_license_keys' );
	$license_keys = empty( $license_keys ) || ! is_array( $license_keys ) ? array() : $license_keys;
	$license_key  = isset( $_GET['key'] ) ? sanitize_text_field( $_GET['key'] ) : '';

	if ( isset( $_GET['activate_license'] ) && $_GET['activate_license'] == 'yes' ) {

		if ( get_option( 'affpilot_license_status' ) === 'activated' ) {
			echo "License key already activated";
			die();
		}

		if ( in_array( $license_key, $license_keys ) ) {
			echo "This license key was already used on this website! Please get a new one from here: <a href='mailto:" . AFFPILOT_AUTHOR_EMAIL . "'>" . AFFPILOT_AUTHOR_EMAIL . "</a>";
			die();
		}

		$email_subject = 'License key activated';
		$email_body    = "License key has been activeted on the website: " . get_bloginfo( 'siteurl' ) . " with license key: <strong>$license_key</strong> and email of the admin is: <strong>" . get_bloginfo( 'admin_email' ) . "</strong>";
		$email_ret     = wp_mail( AFFPILOT_AUTHOR_EMAIL, $email_subject, $email_body );

		if ( $email_ret && ! in_array( $license_key, $license_keys ) ) {

			$license_keys = array_merge( $license_keys, array( $license_key ) );

			array_filter( $license_keys );

			update_option( 'affpilot_license_keys', $license_keys );
			update_option( 'affpilot_license_status', 'activated' );
			echo "License key successfully activated on this website!";
		}

		die();
	}

	if ( isset( $_GET['deactivate_license'] ) && $_GET['deactivate_license'] === 'yes' && in_array( $license_key, $license_keys ) ) {
		delete_option( 'affpilot_license_status' );
		echo "License key successfully deactivated on this website!";
		die();
	}
}, 0 );

if ( get_option( 'affpilot_license_status' ) != 'activated' ) {

	add_action( 'admin_notices', function () {
		printf( '<div class="notice notice-error"><p>%s</p><p><a href="mailto:%s" class="button-primary">%s</a></p></div>',
			esc_html( 'Please activate license key to use AffPilot on this website! ' ), AFFPILOT_AUTHOR_EMAIL, esc_html( 'Email Author' )
		);
	} );

	return;
}

defined( '\ABSPATH' ) || die( 'No direct script access allowed!' );

define( __NAMESPACE__ . '\NS', __NAMESPACE__ . '\\' );
define( NS . 'PLUGIN_PATH', \plugin_dir_path( __FILE__ ) );
define( NS . 'PLUGIN_FILE', __FILE__ );
define( NS . 'PLUGIN_RES', \plugins_url( 'res', __FILE__ ) );
define( NS . 'CUSTOM_MODULES_DIR', 'affpilot-modules' );

require_once PLUGIN_PATH . 'loader.php';

\add_action( 'plugins_loaded', array( '\AffPilot\application\Plugin', 'getInstance' ) );
if ( \is_admin() ) {
	\register_activation_hook( __FILE__, array( \AffPilot\application\Installer::getInstance(), 'activate' ) );
	\register_deactivation_hook( __FILE__, array( \AffPilot\application\Installer::getInstance(), 'deactivate' ) );
	\register_uninstall_hook( __FILE__, array( '\AffPilot\application\Installer', 'uninstall' ) );
	\add_action( 'init', array( '\AffPilot\application\admin\PluginAdmin', 'getInstance' ) );
}
