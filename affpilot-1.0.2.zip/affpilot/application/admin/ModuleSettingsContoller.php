<?php

namespace AffPilot\application\admin;
defined('\ABSPATH') || exit;

use AffPilot\application\Plugin;
use AffPilot\application\components\ModuleManager;

/**
 * ModuleSettingsContoller class file
 *
 * @author keywordrush.com <support@keywordrush.com>
 * @link https://www.keywordrush.com
 * @copyright Copyright &copy; 2020 keywordrush.com
 */
class ModuleSettingsContoller {

    const slug = 'affpilot-modules';
    
    public function __construct()
    {
        \add_action('admin_menu', array($this, 'add_admin_menu'));
    }

    public function add_admin_menu()
    {
        \add_submenu_page(Plugin::slug(), __('Modules', 'affpilot') . ' &lsaquo; Affpilot', __('Modules', 'affpilot'), 'manage_options', self::slug, array($this, 'actionIndex'));
    }

    public function actionIndex()
    {
        \wp_enqueue_style('affpilot-bootstrap', \AffPilot\PLUGIN_RES . '/bootstrap/css/affpilot-bootstrap.min.css', array(), Plugin::version());
        PluginAdmin::getInstance()->render('module_index', array('modules' => ModuleManager::getInstance()->getConfigurableModules()));
    }


}
