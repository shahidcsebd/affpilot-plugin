<?php

namespace AffPilot\application;

defined('\ABSPATH') || exit;

use AffPilot\application\admin\GeneralConfig;
use AffPilot\application\helpers\CurrencyHelper;
use AffPilot\application\components\ExternalFeaturedImage;

/**
 * Plugin class file
 *
 * @author keywordrush.com <support@keywordrush.com>
 * @link https://www.keywordrush.com
 * @copyright Copyright &copy; 2022 keywordrush.com
 */
class Plugin {

    const version = '1.0.0';
    const db_version = 54;
    const wp_requires = '4.6.1';
    const slug = 'affpilot';
    const short_slug = 'cegg';
    const name = 'Affpilot';
    const api_base = 'https://www.keywordrush.com/api/v1';
    const api_base2 = '';
    const product_id = 302;
    const website = 'https://www.keywordrush.com';
    const supportUri = 'https://www.keywordrush.com/contact';
    const panelUri = 'https://www.keywordrush.com/panel';

    private static $instance = null;
    private static $is_pro = null;
    private static $is_envato = null;

    public static function getInstance()
    {
        if (self::$instance == null)
            self::$instance = new self;

        return self::$instance;
    }

    private function __construct()
    {
        $this->loadTextdomain();
        if (self::isFree() || (self::isPro() && self::isActivated()) || self::isEnvato())
        {
            if (!\is_admin())
            {
                \add_action('wp_enqueue_scripts', array($this, 'registerScripts'));
                \add_action('amp_post_template_css', array($this, 'registerAmpStyles'));
                EggShortcode::getInstance();
                BlockShortcode::getInstance();
                ModuleViewer::getInstance()->init();
                ModuleUpdateVisit::getInstance()->init();
                LocalRedirect::initAction();
                CurrencyHelper::getInstance(GeneralConfig::getInstance()->option('lang'));
                ProductSearch::initAction();
            }
            PriceAlert::getInstance()->init();
            AutoblogScheduler::initAction();
            ModuleUpdateScheduler::initAction();
            WooIntegrator::initAction();
            ExternalFeaturedImage::initAction();
            if (!self::isFree())
                DataRestController::getInstance()->init();
                
            new ProductSearchWidget;
            new PriceMoversWidget;
        }
    }

    public function registerScripts()
    {
        \wp_register_style('bootstrap', \AffPilot\PLUGIN_RES . '/bootstrap/css/affpilot-bootstrap.min.css', array(), '' . Plugin::version());
        \wp_register_script('bootstrap', \AffPilot\PLUGIN_RES . '/bootstrap/js/bootstrap.min.js', array('jquery'), null, false);
        \wp_register_script('bootstrap-tab', \AffPilot\PLUGIN_RES . '/bootstrap/js/tab.js', array('jquery'), null, false);
        \wp_register_script('bootstrap-tooltip', \AffPilot\PLUGIN_RES . '/bootstrap/js/tooltip.js', array('jquery'), null, false);
        \wp_register_script('bootstrap-popover', \AffPilot\PLUGIN_RES . '/bootstrap/js/popover.js', array('bootstrap-tooltip'), null, false);
        \wp_register_style('affpilot-products', \AffPilot\PLUGIN_RES . '/css/products.css', array(), '' . Plugin::version());
        \wp_register_script('raphaeljs', \AffPilot\PLUGIN_RES . '/js/morrisjs/raphael.min.js', array('jquery'));
        \wp_register_script('morrisjs', \AffPilot\PLUGIN_RES . '/js/morrisjs/morris.min.js', array('raphaeljs'));
        \wp_register_style('morrisjs', \AffPilot\PLUGIN_RES . '/js/morrisjs/morris.min.css');
    }

    public static function version()
    {
        return self::version;
    }

    public static function slug()
    {
        return self::getSlug();
    }

    public static function getSlug()
    {
        return self::slug;
    }

    public static function getShortSlug()
    {
        return self::short_slug;
    }

    public static function getName()
    {
        return self::name;
    }

    public static function getApiBase()
    {
        return self::api_base;
    }

    public static function isFree()
    {
        return !self::isPro();
    }

    public static function isPro()
    {
		return true;
    }

    public static function isEnvato()
    {
        if (self::$is_envato === null)
        {
            if (isset($_SERVER['KEYWORDRUSH_DEVELOPMENT']) && $_SERVER['KEYWORDRUSH_DEVELOPMENT'] == '16203273895503427')
                self::$is_envato = false;
            elseif (class_exists("\\AffPilot\\application\\admin\\EnvatoConfig", true) || \get_option(Plugin::slug . '_env_install'))
                self::$is_envato = true;
            else
                self::$is_envato = false;
        }
        return self::$is_envato;
    }

    public static function isActivated()
    {
	    return true;
    }

    public static function isInactiveEnvato()
    {
        if (self::isEnvato() && !self::isActivated())
            return true;
        else
            return false;
    }

    public static function apiRequest($params = array())
    {
        $api_urls = array(self::api_base);
        if (self::api_base2)
            $api_urls[] = self::api_base2;

        foreach ($api_urls as $api_url)
        {
            $response = \wp_remote_post($api_url, $params);
            if (\is_wp_error($response))
                continue;

            $response_code = (int) \wp_remote_retrieve_response_code($response);
            if ($response_code == 200)
                return $response;
            else
                return false;
        }
        return false;
    }

    private function loadTextdomain()
    {
        // plugin admin
        \load_plugin_textdomain('affpilot', false, dirname(\plugin_basename(\AffPilot\PLUGIN_FILE)) . '/languages/');

        // frontend templates
        $lang = GeneralConfig::getInstance()->option('lang');
        $mo_files = array();
        if (defined('LOCO_LANG_DIR'))
            $mo_files[] = \trailingslashit(LOCO_LANG_DIR) . 'plugins/affpilot-tpl-' . $lang . '.mo'; // loco lang dir
        $mo_files[] = \trailingslashit(WP_LANG_DIR) . 'plugins/affpilot-tpl-' . $lang . '.mo'; // wp lang dir
        $mo_files[] = \AffPilot\PLUGIN_PATH . 'languages/tpl/affpilot-tpl-' . strtoupper($lang) . '.mo'; // plugin lang dir
        foreach ($mo_files as $mo_file)
        {
            if (file_exists($mo_file) && is_readable($mo_file))
            {
                if (\load_textdomain('affpilot-tpl', $mo_file))
                    return;
            }
        }
    }

    public static function getPluginDomain()
    {
        return 'https://www.keywordrush.com/';
    }

    public static function pluginSiteUrl()
    {
        return self::getPluginDomain() . 'affpilot?utm_source=cegg&utm_medium=referral&utm_campaign=plugin';
    }

    public static function pluginDocsUrl()
    {
        return 'https://ce-docs.keywordrush.com';
    }

    public function registerAmpStyles()
    {
        echo '.affpilot-container table td{padding:0} .affpilot-container .btn,.affpilot-container .affpilot-price{white-space:nowrap;font-weight:700}.affpilot-couponcode,.affpilot-gridbox a{text-decoration:none}.affpilot-container .affpilot-gridbox{box-shadow:0 8px 16px -6px #eee;border:1px solid #ddd;margin-bottom:25px;padding:20px}.affpilot-container .affpilot-listcontainer .row-products>div{margin-bottom:12px}.affpilot-container .btn{display:inline-block;padding:7px 14px;margin-bottom:0;font-size:14px;line-height:1.42857143;text-align:center;vertical-align:middle;touch-action:manipulation;cursor:pointer;user-select:none;background-image:none;border:1px solid transparent;border-radius:4px}.affpilot-container .btn-danger{color:#fff;background-color:#5cb85c;border-color:#4cae4c;text-decoration:none}.affpilot-container .panel-default{border:1px solid #ddd;padding:20px}.affpilot-price-alert-wrap,.affpilot-price-tracker-item div[id$=chart]{display:none}.affpilot-price-tracker-panel .btn{margin-bottom:6px}.affpilot-container .affpilot-no-top-margin{margin-top:0}.affpilot-container .affpilot-mb5{margin-bottom:5px}.affpilot-container .affpilot-mb10{margin-bottom:10px}.affpilot-container .affpilot-mb15{margin-bottom:15px}.affpilot-container .affpilot-mb20{margin-bottom:20px}.affpilot-container .affpilot-mb25{margin-bottom:25px}.affpilot-container .affpilot-mb30{margin-bottom:30px}.affpilot-container .affpilot-mb35{margin-bottom:35px}.affpilot-container .affpilot-lineh-20{line-height:20px}.affpilot-container .affpilot-mr10{margin-right:10px}.affpilot-container .affpilot-mr5{margin-right:5px}.affpilot-container .btn.affpilot-btn-big{padding:13px 60px;line-height:1;font-size:20px;font-weight:700}.affpilot-couponcode{text-align:center;background:#efffda;padding:8px;display:block;border:2px dashed #5cb85c;margin-bottom:12px}.affpilot-bordered-box{border:2px solid #ededed;padding:25px}.affpilot-price-tracker-item .affpilot-price{font-size:22px;font-weight:700}.affpilot-list-coupons .btn{font-size:16px;font-weight:700;display:block}.affpilot-listlogo-title{line-height:18px;font-size:15px}.affpilot-list-withlogos .affpilot-price,.affpilot-listcontainer .affpilot-price{font-weight:700;font-size:20px;color:#5aaf0b}.affpilot-container .affpilot-list-withlogos .btn{font-weight:700;font-size:15px;padding:8px 16px}.affpilot-price-row strike{opacity:.42;font-size:90%}.affpilot-list-logo-title{font-weight:700;font-size:17px}.affpilot-container .affpilot-btn-grid .btn{display:block;margin-bottom:10px}#cegg_market .affpilot-image-container img{max-height:350px}.affpilot-review-block{padding:20px;border:1px solid #eee}.affpilot-line-hr{clear:both;border-top:1px solid #eee;height:1px}.amp-wp-article-content .affpilot-btn-row amp-img,.amp-wp-article-content .affpilot-desc-cell amp-img,.amp-wp-article-content .affpilot-price-tracker-panel .affpilot-mb5 amp-img,.amp-wp-article-content .producttitle amp-img{display:inline-block;margin:0 4px 0 0;vertical-align:middle}.affpilot-container .affpilot-promotion{top:25px;left:0;position:absolute;z-index:10}.affpilot-container .affpilot-discount{background-color:#eb5e58;border-radius:0 4px 4px 0;color:#fff;display:inline-block;font-size:16px;padding:3px 5px}.affpilot-thumb{position:relative}'
        . '@media (max-width: 767px) {body .affpilot-container .hidden-xs {display: none;} body .affpilot-container .visible-xs {display: block;}} body .affpilot-container .visible-xs {display: none;}';
    }

}
