<?php defined('\ABSPATH') || exit; ?>

<?php

function _cegg_print_module_item(array $modules)
{
    foreach ($modules as $module)
    {
        echo '<a href="?page=' . \esc_attr($module->getConfigInstance()->page_slug()) . '" class = "list-group-item">';
        echo \esc_html($module->getName());
        if ($module->isActive() && !$module->isDeprecated())
            echo '<span class="label label-success">' . __('Active', 'affpilot') . '</span>';
        if ($module->isDeprecated())
            echo '<span class="label label-warning">' . __('Deprecated', 'affpilot') . '</span>';
        if ($module->isNew() && !$module->isFeedParser())
            echo '<span class="label label-info">' . __('New', 'affpilot') . '</span>';
        echo '</a>';
    }
}
?>

<?php if (\AffPilot\application\Plugin::isFree() || \AffPilot\application\Plugin::isInactiveEnvato()): ?>
    <div class="affpilot-maincol">
    <?php endif; ?>


    <div class="wrap">

        <h2>
            <?php _e('Module Settings', 'affpilot'); ?>
            <span class="affpilot-label affpilot-label-pro">pro <small><?php echo \AffPilot\application\Plugin::version(); ?></small></span>
        </h2>


        <h2 class="nav-tab-wrapper">
            <a href="?page=affpilot-modules" class="nav-tab<?php if (!empty($_GET['page']) && $_GET['page'] == 'affpilot-modules') echo ' nav-tab-active'; ?>">
                <span class="dashicons dashicons-menu-alt3"></span>
            </a>
            <?php foreach (AffPilot\application\components\ModuleManager::getInstance()->getConfigurableModules(true) as $m): ?>
                <?php if ($m->isDeprecated() && !$m->isActive()) continue; ?>
                <?php $c = $m->getConfigInstance(); ?>
                <a href="?page=<?php echo \esc_attr($c->page_slug()); ?>" class="nav-tab<?php if (!empty($_GET['page']) && $_GET['page'] == $c->page_slug()) echo ' nav-tab-active'; ?>">
                    <span<?php if ($m->isDeprecated()): ?> style="color: darkgray;"<?php endif; ?>>
                        <?php echo \esc_html($m->getName()); ?>                    
                    </span>
                </a>
            <?php endforeach; ?>
        </h2>

        <br />        
        <div class="affpilot-container">
            <div class="row">
                <div class="col-md-4 col-xs-12">

                    <div class="panel panel-default">
                        <div class="panel-heading"><h3 class="panel-title"><?php _e('Product modules', 'affpilot'); ?></h3></div>
                        <div class="list-group">
                            <?php _cegg_print_module_item(\AffPilot\application\helpers\AdminHelper::getProductModules()); ?>
                        </div>
                    </div>    

                </div>


                <div class="col-md-4 col-xs-12">

                    <div class="panel panel-default">
                        <div class="panel-heading"><h3 class="panel-title"><?php _e('Content modules', 'affpilot'); ?></h3></div>
                        <div class="list-group">
                            <?php _cegg_print_module_item(\AffPilot\application\helpers\AdminHelper::getContentModules()); ?>
                        </div>
                    </div>                     

                </div>

            </div>
        </div>
    </div>

    <?php if (\AffPilot\application\Plugin::isFree() || \AffPilot\application\Plugin::isInactiveEnvato()): ?>
    </div>    
    <?php include('_promo_box.php'); ?>
<?php endif; ?>  