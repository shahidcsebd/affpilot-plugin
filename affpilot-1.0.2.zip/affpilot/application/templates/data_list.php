<?php
defined( '\ABSPATH' ) || exit;

use AffPilot\application\helpers\TemplateHelper;

if ( TemplateHelper::isModuleDataExist( $items, 'Amazon', 'AmazonNoApi' ) ) {
	\wp_enqueue_script( 'affpilot-frontend', \AffPilot\PLUGIN_RES . '/js/frontend.js', array( 'jquery' ) );
}

\wp_enqueue_script( 'bootstrap-popover' );
?>

<div class="affpilot-container affpilot-list">

	<?php if ( $title ): ?>
        <h3><?php echo \esc_html( $title ); ?></h3>
	<?php endif; ?>

    <div class="affpilot-listcontainer">

        <div class="row-products table-head">
            <div class="col-md-1 col-sm-1 col-xs-12 affpilot-title-cell"><span>Serial</span></div>
            <div class="col-md-2 col-sm-2 col-xs-12 affpilot-image-cell"><span>Image</span></div>
            <div class="col-md-3 col-sm-3 col-xs-12 affpilot-desc-cell hidden-xs"><span>Product Title</span></div>
            <div class="col-md-3 col-sm-3 col-xs-12 affpilot-btn-cell"><span>Check Price</span></div>
        </div>

		<?php $serial = 0;
		foreach ( $items as $item ): $serial ++; ?>
			<?php $this->renderBlock( 'list_row', array( 'item' => $item, 'serial' => $serial ) ); ?>
		<?php endforeach; ?>
    </div>

	<?php if ( $module_id == 'Amazon' || $module_id == 'AmazonNoApi' ): ?>
        <div class="row affpilot-no-top-margin">
            <div class="col-md-12 text-right text-muted">
                <small>
					<?php echo sprintf( TemplateHelper::__( 'Last updated on %s' ), TemplateHelper::getLastUpdateFormatted( $module_id, $post_id ) ); ?>
					<?php TemplateHelper::printAmazonDisclaimer(); ?>
                </small>
            </div>
        </div>
	<?php endif; ?>

</div>
