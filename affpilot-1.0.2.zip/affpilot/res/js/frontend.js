jQuery(document).ready(function ()
{
    jQuery("i.affpilot-disclaimer").click(function () {
        var $title = jQuery(this).find(".affpilot-disclaimer-title");
        if (!$title.length) {
            jQuery(this).append('<span class="affpilot-disclaimer-title">' + jQuery(this).attr("title") + '</span>');
        } else {
            $title.remove();
        }
    });

});
