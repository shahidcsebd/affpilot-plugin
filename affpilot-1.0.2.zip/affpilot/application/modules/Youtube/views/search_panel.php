<?php defined('\ABSPATH') || exit; ?>
<select class="col-md-4 input-sm" ng-model="query_params.<?php echo $module_id; ?>.license">
    <option value="any"><?php _e('Any license', 'affpilot'); ?></option>
    <option value="creativeCommon"><?php _e('Creative Commons', 'affpilot'); ?></option>
    <option value="youtube"><?php _e('Standard license', 'affpilot'); ?></option>
</select>
<select class="col-md-4 input-sm" ng-model="query_params.<?php echo $module_id; ?>.order">
    <option value="date"><?php _e('Date', 'affpilot'); ?></option>
    <option value="rating"><?php _e('Rating', 'affpilot'); ?></option>
    <option value="relevance"><?php _e('Relevance', 'affpilot'); ?></option>
    <option value="title"><?php _e('Title', 'affpilot'); ?></option>
    <option value="viewCount"><?php _e('Views', 'affpilot'); ?></option>
</select>