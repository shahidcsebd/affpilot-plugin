<?php

namespace AffPilot\application\admin;

defined('\ABSPATH') || exit;

use AffPilot\application\components\Config;
use AffPilot\application\Plugin;
use AffPilot\application\admin\PluginAdmin;
use AffPilot\application\models\PriceAlertModel;
use AffPilot\application\components\ModuleManager;
use AffPilot\application\helpers\TextHelper;

/**
 * GeneralSettings class file
 *
 * @author keywordrush.com <support@keywordrush.com>
 * @link https://www.keywordrush.com
 * @copyright Copyright &copy; 2021 keywordrush.com
 */
class GeneralConfig extends Config {

    private static $affiliate_modules;

    public function page_slug()
    {
        return Plugin::slug() . '';
    }

    public function option_name()
    {
        return 'affpilot_options';
    }

    public function add_admin_menu()
    {
        \add_submenu_page(Plugin::slug, __('Settings', 'affpilot') . ' &lsaquo; Affpilot', __('Settings', 'affpilot'), 'manage_options', $this->page_slug, array($this, 'settings_page'));
    }

    private static function frontendTexts()
    {
        return array(
            'in stock' => __('in stock', 'affpilot-tpl'),
            'out of stock' => __('out of stock', 'affpilot-tpl'),
            'Last updated on %s' => __('Last updated on %s', 'affpilot-tpl'),
            'Last Amazon price update was: %s' => __('Last Amazon price update was: %s', 'affpilot-tpl'),
            'as of %s' => __('as of %s', 'affpilot-tpl'),
            '%d new from %s' => __('%d new from %s', 'affpilot-tpl'),
            '%d used from %s' => __('%d used from %s', 'affpilot-tpl'),
            'Free shipping' => __('Free shipping', 'affpilot-tpl'),
            'OFF' => __('OFF', 'affpilot-tpl'),
            'Plus %s Cash Back' => __('Plus %s Cash Back', 'affpilot-tpl'),
            'Price' => __('Price', 'affpilot-tpl'),
            'Features' => __('Features', 'affpilot-tpl'),
            'Specifications' => __('Specifications', 'affpilot-tpl'),
            'Statistics' => __('Statistics', 'affpilot-tpl'),
            'Current Price' => __('Current Price', 'affpilot-tpl'),
            'Highest Price' => __('Highest Price', 'affpilot-tpl'),
            'Lowest Price' => __('Lowest Price', 'affpilot-tpl'),
            'Since %s' => __('Since %s', 'affpilot-tpl'),
            'Last price changes' => __('Last price changes', 'affpilot-tpl'),
            'Start date: %s' => __('Start date: %s', 'affpilot-tpl'),
            'End date: %s' => __('End date: %s', 'affpilot-tpl'),
            'Set Alert for' => __('Set Alert for', 'affpilot-tpl'),
            'Price History for' => __('Price History for', 'affpilot-tpl'),
            'Create Your Free Price Drop Alert!' => __('Create Your Free Price Drop Alert!', 'affpilot-tpl'),
            'Wait For A Price Drop' => __('Wait For A Price Drop', 'affpilot-tpl'),
            'Your Email' => __('Your Email', 'affpilot-tpl'),
            'Desired Price' => __('Desired Price', 'affpilot-tpl'),
            'SET ALERT' => __('SET ALERT', 'affpilot-tpl'),
            'You will receive a notification when the price drops.' => __('You will receive a notification when the price drops.', 'affpilot-tpl'),
            'I agree to the %s.' => __('I agree to the %s.', 'affpilot-tpl'),
            'Privacy Policy' => __('Privacy Policy', 'affpilot-tpl'),
            'Sorry. No products found.' => __('Sorry. No products found.', 'affpilot-tpl'),
            'Search Results for "%s"' => __('Search Results for "%s"', 'affpilot-tpl'),
            'Price per unit: %s' => __('Price per unit: %s', 'affpilot-tpl'),
            'today' => __('today', 'affpilot-tpl'),
            '%d day ago' => __('%d day ago', 'affpilot-tpl'),
            '%d days ago' => __('%d days ago', 'affpilot-tpl'),
        );
    }

    public static function langs()
    {
        return array(
            'ar' => 'Arabic (ar)',
            'bg' => 'Bulgarian (bg)',
            'ca' => 'Catalan (ca)',
            'zh_CN' => 'Chinese (zh_CN)',
            'zh_TW' => 'Chinese (zh_TW)',
            'hr' => 'Croatian (hr)',
            'cs' => 'Czech (cs)',
            'da' => 'Danish (da)',
            'nl' => 'Dutch (nl)',
            'en' => 'English (en)',
            'et' => 'Estonian (et)',
            'tl' => 'Filipino (tl)',
            'fi' => 'Finnish (fi)',
            'fr' => 'French (fr)',
            'de' => 'German (de)',
            'el' => 'Greek (el)',
            'iw' => 'Hebrew (iw)',
            'hi' => 'Hindi (hi)',
            'hu' => 'Hungarian (hu)',
            'is' => 'Icelandic (is)',
            'id' => 'Indonesian (id)',
            'it' => 'Italian (it)',
            'ja' => 'Japanese (ja)',
            'ko' => 'Korean (ko)',
            'lv' => 'Latvian (lv)',
            'lt' => 'Lithuanian (lt)',
            'ms' => 'Malay (ms)',
            'no' => 'Norwegian (no)',
            'fa' => 'Persian (fa)',
            'pl' => 'Polish (pl)',
            'pt' => 'Portuguese (pt)',
            'br' => 'Portuguese (br)',
            'ro' => 'Romanian (ro)',
            'ru' => 'Russian (ru)',
            'sr' => 'Serbian (sr)',
            'sk' => 'Slovak (sk)',
            'sl' => 'Slovenian (sl)',
            'es' => 'Spanish (es)',
            'sv' => 'Swedish (sv)',
            'th' => 'Thai (th)',
            'tr' => 'Turkish (tr)',
            'uk' => 'Ukrainian (uk)',
            'ur' => 'Urdu (ur)',
            'vi' => 'Vietnamese (vi)',
        );
    }

    protected function options()
    {

        $post_types = get_post_types(array('public' => true), 'names');
        if (isset($post_types['attachment']))
            unset($post_types['attachment']);

        $total_price_alerts = PriceAlertModel::model()->count('status = ' . PriceAlertModel::STATUS_ACTIVE);
        $sent_price_alerts = PriceAlertModel::model()->count('status = ' . PriceAlertModel::STATUS_DELETED
                . ' AND TIMESTAMPDIFF( DAY, complet_date, "' . \current_time('mysql') . '") <= ' . PriceAlertModel::CLEAN_DELETED_DAYS);

        $export_url = \get_admin_url(\get_current_blog_id(), 'admin.php?page=affpilot-tools&action=subscribers-export');

        return array(
            'lang' => array(
                'title' => __('Website language', 'affpilot'),
                'description' => __('The frontend language.', 'affpilot'),
                'dropdown_options' => self::langs(),
                'callback' => array($this, 'render_dropdown'),
                'default' => self::getDefaultLang(),
                'section' => __('General settings', 'affpilot'),
            ),
            'post_types' => array(
                'title' => 'Post Types',
                'description' => __('What post types do you want to use for Affpilot?', 'affpilot'),
                'checkbox_options' => $post_types,
                'callback' => array($this, 'render_checkbox_list'),
                'default' => array('post', 'page', 'product'),
                'section' => __('General settings', 'affpilot'),
            ),
            'cashback_integration' => array(
                'title' => __('Cashback Tracker integration', 'affpilot'),
                'description' => sprintf(__('Integration with %s plugin.', 'affpilot'), '<a target="_blanl" href="https://www.keywordrush.com/cashbacktracker">Cashback Tracker</a>') . ' ' .
                __('Convert all affiliate links to trackable cashback links if possible.', 'affpilot'),
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => array(
                    'enabled' => __('Enabled', 'affpilot'),
                    'disabled' => __('Disabled', 'affpilot'),
                ),
                'default' => 'enabled',
                'section' => __('General settings', 'affpilot'),
            ),
            'external_featured_images' => array(
                'title' => __('External featured images', 'affpilot'),
                'description' => __('Featured images from URL', 'affpilot') .
                '<p class="description">' . __('', 'affpilot') . '</p>',
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => array(
                    'disabled' => __('Disabled - internal image is used', 'affpilot'),
                    'enabled_internal_priority' => __('Enabled - internal image has priority', 'affpilot'),
                    'enabled_external_priority' => __('Enabled - external image has priority', 'affpilot'),
                ),
                'default' => 'disabled',
                'section' => __('General settings', 'affpilot'),
            ),
            'rel_attribute' => array(
                'title' => 'Rel attribute for affiliate links',
                'description' => sprintf(__('<a target="_blank" href="%s">Qualify</a> your affiliate links to Google.', 'affpilot'), 'https://support.google.com/webmasters/answer/96569'),
                'checkbox_options' => array(
                    'nofollow' => 'nofollow',
                    'sponsored' => 'sponsored',
                    'external' => 'external',
                    'noopener' => 'noopener',
                    'noreferrer' => 'noreferrer',
                    'ugc' => 'ugc',
                ),
                'callback' => array($this, 'render_checkbox_list'),
                'default' => array('nofollow'),
                'section' => __('Frontend', 'affpilot'),
            ),
            'woocommerce_modules' => array(
                'title' => __('Modules for synchronization', 'affpilot'),
                'description' => __('Select modules for automatic synchronization with WooCommerce.', 'affpilot'),
                'checkbox_options' => self::getAffiliteModulesList(),
                'callback' => array($this, 'render_checkbox_list'),
                'default' => array(),
                'section' => __('WooCommerce', 'affpilot'),
            ),
            'woocommerce_product_sync' => array(
                'title' => __('Automatic synchronization', 'affpilot'),
                'description' => __('How to choose product for automatic synchronization with WooCommerce.', 'affpilot'),
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => array(
                    'min_price' => __('Minimum price', 'affpilot'),
                    'max_price' => __('Maximum price', 'affpilot'),
                    'random' => __('Random', 'affpilot'),
                    'manually' => __('Manually only', 'affpilot'),
                ),
                'default' => 'min_price',
                'section' => __('WooCommerce', 'affpilot'),
            ),
            'woocommerce_attributes_sync' => array(
                'title' => __('Import product attributes', 'affpilot'),
                'description' => __('Import attributes automatically for synchronized product.', 'affpilot'),
                'callback' => array($this, 'render_checkbox'),
                'default' => false,
                'section' => __('WooCommerce', 'affpilot'),
            ),
            'woocommerce_attributes_filter' => array(
                'title' => __('Global attributes filter', 'affpilot'),
                'description' => __('How to create wocommerce attributes when synchronizing. Please, read documentation about them in our docs.', 'affpilot'),
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => array(
                    '' => __('Default filter', 'affpilot'),
                    'whitelist' => __('Whitelist attribute names', 'affpilot'),
                    'blacklist' => __('Blacklist attribute names', 'affpilot'),
                ),
                'default' => 'whitelist',
                'section' => __('WooCommerce', 'affpilot'),
            ),
            'woocommerce_attributes_list' => array(
                'title' => __('Attributes list', 'affpilot'),
                'description' => __('Black / white list of woocommerce global (filterable) attributes. Enter a comma separated list.', 'affpilot'),
                'callback' => array($this, 'render_textarea'),
                'default' => '',
                'section' => __('WooCommerce', 'affpilot'),
            ),
            'woocommerce_echo_update_date' => array(
                'title' => __('Update date', 'affpilot'),
                'description' => __('Show price update date for WooCommerce products.', 'affpilot'),
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => array(
                    '' => __('Disabled', 'affpilot'),
                    'amazon' => __('Amazon only', 'affpilot'),
                    'all' => __('All modules', 'affpilot'),
                ),
                'default' => 'amazon',
                'section' => __('WooCommerce', 'affpilot'),
            ),
            'woocommerce_echo_price_per_unit' => array(
                'title' => __('Price per unit', 'affpilot'),
                'description' => __('Show price per unit', 'affpilot') .
                '<p class="description">' .
                __('This option is available for Amazon and Ebay modules only.', 'affpilot') . '<br>' .
                '</p>',
                'callback' => array($this, 'render_checkbox'),
                'default' => false,
                'section' => __('WooCommerce', 'affpilot'),
            ),
            'woocommerce_btn_text' => array(
                'title' => __('Buy button text', 'affpilot'),
                'description' => __('Overwrite the button text for external products.', 'affpilot') . ' ' . __('You can use tags: %MERCHANT%, %DOMAIN%, %PRICE%, %STOCK_STATUS%.', 'affpilot'),
                'callback' => array($this, 'render_input'),
                'default' => '',
                'validator' => array(
                    'strip_tags',
                ),
                'section' => __('WooCommerce', 'affpilot'),
            ),
            'filter_bots' => array(
                'title' => __('Filter bots', 'affpilot'),
                'description' => __('Bots can\'t activate parsers.', 'affpilot') .
                '<p class="description">' . __('Updating price and keyword updating is made with page opening. If we determine update by useragent, and page is opened by one of known bots, no parsers will work in this case.', 'affpilot') . '</p>',
                'callback' => array($this, 'render_checkbox'),
                'default' => true,
                'section' => __('General settings', 'affpilot'),
            ),
            'price_history_days' => array(
                'title' => __('Price history', 'affpilot'),
                'description' => __('How long save price history. 0 - deactivate price history.', 'affpilot'),
                'callback' => array($this, 'render_input'),
                'default' => 180,
                'validator' => array(
                    'trim',
                    'absint',
                    array(
                        'call' => array('\AffPilot\application\helpers\FormValidator', 'less_than_equal_to'),
                        'arg' => 1875,
                        'message' => sprintf(__('The field "%s" can\'t be more than %d.', 'affpilot'), __('Price history', 'affpilot'), 365),
                    ),
                ),
                'section' => __('Price alerts', 'affpilot'),
            ),
            'price_drops_days' => array(
                'title' => __('Price drops period', 'affpilot'),
                'description' => __('Used for Price Movers widget.', 'affpilot'),
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => array(
                    '1.' => __('The last 1 day', 'affpilot'),
                    '2.' => sprintf(__('The last %d days', 'affpilot'), 2),
                    '3.' => sprintf(__('The last %d days', 'affpilot'), 3),
                    '4.' => sprintf(__('The last %d days', 'affpilot'), 4),
                    '5.' => sprintf(__('The last %d days', 'affpilot'), 5),
                    '6.' => sprintf(__('The last %d days', 'affpilot'), 6),
                    '7.' => sprintf(__('The last %d days', 'affpilot'), 7),
                    '21.' => sprintf(__('The last %d days', 'affpilot'), 21),
                    '30.' => sprintf(__('The last %d days', 'affpilot'), 30),
                    '90.' => sprintf(__('The last %d days', 'affpilot'), 90),
                    '180.' => sprintf(__('The last %d days', 'affpilot'), 180),
                    '360.' => sprintf(__('The last %d days', 'affpilot'), 360),
                ),
                'default' => '30.',
                'section' => __('Price alerts', 'affpilot'),
            ),
            'price_alert_enabled' => array(
                'title' => 'Price alert',
                'description' => __('Allow visitors to subscribe for price drop alert on email.', 'affpilot') .
                '<p class="description">' . sprintf(__('Active subscriptions now: <b>%d</b>', 'affpilot'), $total_price_alerts) .
                '. ' . sprintf(__('Messages are sent for last %d days: <b>%d</b>', 'affpilot'), PriceAlertModel::CLEAN_DELETED_DAYS, $sent_price_alerts) . '.' .
                ' ' . sprintf(__('Export: [ <a href="%s">All</a> | <a href="%s">Active</a> ]', 'affpilot'), $export_url, $export_url . '&active_only=true') . '</p>' .
                '<p class="description">' .
                __('"Price history" option must be enabled.', 'affpilot') . '<br>' .
                __('Recommendation: Go to Settings - Privacy and select Privacy Policy page.', 'affpilot') .
                '</p>',
                'callback' => array($this, 'render_checkbox'),
                'default' => true,
                'section' => __('Price alerts', 'affpilot'),
            ),
            'price_alert_mode' => array(
                'title' => __('Price alert mode', 'affpilot'),
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => array(
                    'product' => __('Separate alerts for each product', 'affpilot'),
                    'post' => __('General alert for all products in a post', 'affpilot'),
                ),
                'default' => '',
                'section' => __('Price alerts', 'affpilot'),
            ),
            'from_name' => array(
                'title' => __('From Name', 'affpilot'),
                'description' => __('This name will appear in the From Name column of emails sent from CE plugin.', 'affpilot'),
                'callback' => array($this, 'render_input'),
                'default' => '',
                'validator' => array(
                    'trim',
                    'allow_empty',
                ),
                'section' => __('Price alerts', 'affpilot'),
            ),
            'from_email' => array(
                'title' => __('From Email', 'affpilot'),
                'description' => __('Customize the From Email address.', 'affpilot') . ' ' . __('To avoid your email being marked as spam, it is recommended your "from" match your website.', 'affpilot'),
                'callback' => array($this, 'render_input'),
                'default' => '',
                'validator' => array(
                    'trim',
                    'allow_empty',
                    array(
                        'call' => array('\AffPilot\application\helpers\FormValidator', 'valid_email'),
                        'message' => sprintf(__('Field "%s" filled with wrong data.', 'affpilot'), 'Email'),
                    ),
                ),
                'section' => __('Price alerts', 'affpilot'),
            ),
            'email_template_activation' => array(
                'title' => __('Activation email template', 'affpilot'),
                'description' => sprintf(__('Use the following tags: %s.', 'affpilot'), '%POST_ID%, %POST_URL%, %POST_TITLE%, %PRODUCT_TITLE%, %VALIDATE_URL%, %UNSUBSCRIBE_URL%') .
                '<br>' . sprintf(__('%s is required tag.', 'affpilot'), '%VALIDATE_URL%') . ' ' .
                sprintf(__('Use like %s.', 'affpilot'), \esc_html('<a href="%VALIDATE_URL%">%VALIDATE_URL%</a>')),
                'callback' => array($this, 'render_textarea'),
                'default' => '',
                'section' => __('Price alerts', 'affpilot'),
                'validator' => array(
                    '\wp_kses_post',
                    'trim',
                ),
            ),
            'email_template_alert' => array(
                'title' => __('Price alert email template', 'affpilot'),
                'description' => sprintf(__('Use the following tags: %s.', 'affpilot'), '%POST_ID%, %POST_URL%, %POST_TITLE%, %PRODUCT_TITLE%, %START_PRICE%, %DESIRED_PRICE%, %CURRENT_PRICE%, %SAVED_AMOUNT%, %SAVED_PERCENTAGE%, %UPDATE_DATE%, %UNSUBSCRIBE_URL%'),
                'callback' => array($this, 'render_textarea'),
                'default' => '',
                'section' => __('Price alerts', 'affpilot'),
                'validator' => array(
                    '\wp_kses_post',
                    'trim',
                ),
            ),
            'email_signature' => array(
                'title' => __('Email signature', 'affpilot'),
                'callback' => array($this, 'render_textarea'),
                'default' => '',
                'section' => __('Price alerts', 'affpilot'),
                'validator' => array(
                    '\wp_kses_post',
                    'trim',
                ),
            ),
            'button_color' => array(
                'title' => __('Button color', 'affpilot'),
                'description' => __('Button color for default templates.', 'affpilot'),
                'callback' => array($this, 'render_color_picker'),
                'default' => '#d9534f',
                'validator' => array(
                    'trim',
                ),
                'section' => __('Frontend', 'affpilot'),
            ),
            'price_color' => array(
                'title' => __('Price color', 'affpilot'),
                'description' => __('Price color for default templates.', 'affpilot'),
                'callback' => array($this, 'render_color_picker'),
                'default' => '#dc3545',
                'validator' => array(
                    'trim',
                ),
                'section' => __('Frontend', 'affpilot'),
            ),
            'btn_text_buy_now' => array(
                'title' => __('Buy now button text', 'affpilot'),
                'description' => sprintf(__('It will be used instead of "%s".', 'affpilot'), __('Buy Now', 'affpilot-tpl')) . ' ' . __('You can use tags: %MERCHANT%, %DOMAIN%, %PRICE%, %STOCK_STATUS%.', 'affpilot'),
                'callback' => array($this, 'render_input'),
                'default' => '',
                'validator' => array(
                    'strip_tags',
                ),
                'section' => __('Frontend', 'affpilot'),
            ),
            'btn_text_coupon' => array(
                'title' => __('Coupon button text', 'affpilot'),
                'description' => sprintf(__('It will be used instead of "%s".', 'affpilot'), __('Shop Sale', 'affpilot-tpl')),
                'callback' => array($this, 'render_input'),
                'default' => '',
                'validator' => array(
                    'strip_tags',
                ),
                'section' => __('Frontend', 'affpilot'),
            ),
            'show_stock_status' => array(
                'title' => __('Stock status', 'affpilot'),
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => array(
                    'show_status' => __('Show stock status', 'affpilot'),
                    'hide_status' => __('Hide stock status', 'affpilot'),
                    'show_outofstock' => __('Show OutOfStock status only', 'affpilot'),
                    'show_instock' => __('Show InStock status only', 'affpilot'),
                ),
                'default' => 'show_status',
                'section' => __('Frontend', 'affpilot'),
            ),
            'redirect_prefix' => array(
                'title' => __('Redirect prefix', 'affpilot'),
                'description' => __('Custom prefix for local redirect links.', 'affpilot'),
                'callback' => array($this, 'render_input'),
                'default' => '',
                'validator' => array(
                    'trim',
                    'allow_empty',
                    array(
                        'call' => array('\AffPilot\application\helpers\FormValidator', 'alpha_numeric'),
                        'message' => sprintf(__('The field "%s" can contain only Latin letters and digits.', 'affpilot'), __('Redirect prefix', 'affpilot')),
                    ),
                ),
                'section' => __('General settings', 'affpilot'),
            ),
            'outofstock_product' => array(
                'title' => __('Out of Stock products', 'affpilot'),
                'description' => __('How to deal with Out of Stock products.', 'affpilot'),
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => array(
                    '' => __('Do nothing', 'affpilot'),
                    'hide_price' => __('Hide price', 'affpilot'),
                    'hide_product' => __('Hide product', 'affpilot'),
                ),
                'default' => '',
                'section' => __('General settings', 'affpilot'),
            ),
            'search_modules' => array(
                'title' => __('Search modules', 'affpilot'),
                'description' => __('Select modules to search on frontend.', 'affpilot') . ' ' .
                __('Do not select more than 1-2 modules.', 'affpilot') . '<br>' .
                __('Please note, AE modules work slowly and are not recommended for use as search modules.', 'affpilot') . '<br>' .
                __('Do not forget to add search widget or shorcode [affpilot-search-form].', 'affpilot'),
                'checkbox_options' => self::getAffiliteModulesList(),
                'callback' => array($this, 'render_checkbox_list'),
                'default' => array(),
                'section' => __('Frontend search', 'affpilot'),
            ),
            'search_page_tpl' => array(
                'title' => __('Search page template', 'affpilot'),
                'description' => __('Type of Table for body of search page.', 'affpilot') . ' ' .
                __('You can use shortcodes, for example: [affpilot module=Amazon template=grid]', 'affpilot'),
                'callback' => array($this, 'render_textarea'),
                'default' => '',
                'section' => __('Frontend search', 'affpilot'),
            ),
            'logos' => array(
                'title' => __('Merchant logos', 'affpilot'),
                'description' => __('You can add your own custom merchant logos.', 'affpilot'),
                'callback' => array($this, 'render_logo_fields_block'),
                'validator' => array(
                    array(
                        'call' => array($this, 'formatLogoFields'),
                        'type' => 'filter',
                    ),
                ),
                'default' => array(),
                'section' => __('Frontend', 'affpilot'),
            ),
            'disclaimer_text' => array(
                'title' => __('Amazon disclaimer', 'affpilot'),
                'callback' => array($this, 'render_textarea'),
                'default' => '',
                'validator' => array(
                    'strip_tags',
                ),
                'section' => __('Frontend', 'affpilot'),
            ),
            'merchants' => array(
                'title' => __('Merchant settings', 'affpilot'),
                'callback' => array($this, 'render_merchants_block'),
                'validator' => array(
                    array(
                        'call' => array($this, 'formatMerchantFields'),
                        'type' => 'filter',
                    ),
                ),
                'default' => array(),
                'section' => __('Merchants', 'affpilot'),
            ),
        );
    }

    public static function getDefaultLang()
    {
        $locale = \get_locale();
        $lang = explode('_', $locale);
        if (array_key_exists($lang[0], self::langs()))
            return $lang[0];
        else
            return 'en';
    }

    public function settings_page()
    {
        \wp_enqueue_script('jquery-ui-tabs');
        \wp_enqueue_style('affpilot-admin-ui-css', \AffPilot\PLUGIN_RES . '/css/jquery-ui.min.css', false, \AffPilot\application\Plugin::version);
        \wp_enqueue_style('affpilot-admin-css', \AffPilot\PLUGIN_RES . '/css/admin.css', false, time());

        PluginAdmin::render('settings', array('page_slug' => $this->page_slug()));
    }

    private static function getAffiliteModulesList()
    {
        if (self::$affiliate_modules === null)
        {
            self::$affiliate_modules = ModuleManager::getInstance()->getAffiliteModulesList(true);
        }
        return self::$affiliate_modules;
    }

    public function render_logo_fields_line($args)
    {
        $i = isset($args['_field']) ? $args['_field'] : 0;
        $name = isset($args['value'][$i]['name']) ? $args['value'][$i]['name'] : '';
        $value = isset($args['value'][$i]['value']) ? $args['value'][$i]['value'] : '';

        echo '<input name="' . \esc_attr($args['option_name']) . '['
        . \esc_attr($args['name']) . '][' . $i . '][name]" value="'
        . \esc_attr($name) . '" class="text" placeholder="' . \esc_attr(__('Domain name', 'affpilot')) . '"  type="text"/>';
        echo '<input name="' . \esc_attr($args['option_name']) . '['
        . \esc_attr($args['name']) . '][' . $i . '][value]" value="'
        . \esc_attr($value) . '" class="regular-text ltr" placeholder="' . \esc_attr(__('Logo URL', 'affpilot')) . '"  type="text"/>';
    }

    public function render_logo_fields_block($args)
    {
        if (is_array($args['value']))
            $total = count($args['value']) + 3;
        else
            $total = 3;

        for ($i = 0; $i < $total; $i++)
        {
            echo '<div style="padding-bottom: 5px;">';
            $args['_field'] = $i;
            $this->render_logo_fields_line($args);
            echo '</div>';
        }
        if ($args['description'])
            echo '<p class="description">' . $args['description'] . '</p>';
    }

    public function formatLogoFields($values)
    {
        $results = array();
        foreach ($values as $k => $value)
        {
            $name = trim(\sanitize_text_field($value['name']));
            if ($host = TextHelper::getHostName($values[$k]['name']))
                $name = $host;

            $value = trim(\sanitize_text_field($value['value']));

            if (!$name || !$value)
                continue;

            if (!filter_var($value, FILTER_VALIDATE_URL))
                continue;

            if (in_array($name, array_column($results, 'name')))
                continue;

            $result = array('name' => $name, 'value' => $value);
            $results[] = $result;
        }

        return $results;
    }

    public function render_translation_row($args)
    {
        $field_name = $args['_field_name'];
        $value = isset($args['value'][$field_name]) ? $args['value'][$field_name] : '';

        echo '<input value="' . \esc_attr($field_name) . '" class="regular-text ltr" type="text" readonly />';
        echo ' &#x203A; ';
        echo '<input name="' . \esc_attr($args['option_name']) . '['
        . \esc_attr($args['name']) . '][' . \esc_attr($field_name) . ']" value="'
        . \esc_attr($value) . '" class="regular-text ltr" placeholder="' . \esc_attr(__('Translated string', 'affpilot')) . '"  type="text"/>';
    }

    public function render_translation_block($args)
    {
        if (!$args['value'])
            $args['value'] = array();

        foreach (array_keys(self::frontendTexts()) as $str)
        {
            echo '<div style="padding-bottom: 5px;">';
            $args['_field_name'] = $str;
            $this->render_translation_row($args);
            echo '</div>';
        }
        if ($args['description'])
            echo '<p class="description">' . $args['description'] . '</p>';
    }

    public function frontendTextsSanitize($values)
    {
        foreach ($values as $k => $value)
        {
            $values[$k] = trim(\sanitize_text_field($value));
        }

        return $values;
    }

    public function render_merchant_line($args)
    {
        $i = isset($args['_field']) ? $args['_field'] : 0;
        $name = isset($args['value'][$i]['name']) ? $args['value'][$i]['name'] : '';
        $value = isset($args['value'][$i]['shop_info']) ? $args['value'][$i]['shop_info'] : '';

        echo '<input style="margin-bottom: 5px;" name="' . \esc_attr($args['option_name']) . '['
        . \esc_attr($args['name']) . '][' . $i . '][name]" value="'
        . \esc_attr($name) . '" class="regular-text ltr" placeholder="' . \esc_attr(__('Domain name', 'affpilot')) . '"  type="text"/>';

        echo '<textarea rows="2" name="' . \esc_attr($args['option_name']) . '['
        . \esc_attr($args['name']) . '][' . $i . '][shop_info]" value="'
        . \esc_attr($value) . '" class="large-text code" placeholder="' . \esc_attr(__('Shop info', 'affpilot')) . '"  type="text">' . \esc_html($value) . '</textarea>';
    }

    public function render_merchants_block($args)
    {
        if (is_array($args['value']))
            $total = count($args['value']) + 3;
        else
            $total = 3;

        for ($i = 0; $i < $total; $i++)
        {
            echo '<div style="padding-bottom: 20px;">';
            $args['_field'] = $i;
            $this->render_merchant_line($args);
            echo '</div>';
        }
        if ($args['description'])
            echo '<p class="description">' . $args['description'] . '</p>';
    }

    public function formatMerchantFields($values)
    {
        $results = array();
        foreach ($values as $k => $value)
        {
            $name = strtolower(trim(\sanitize_text_field($value['name'])));
            if ($host = TextHelper::getHostName($values[$k]['name']))
                $name = $host;

            if (!$name)
                continue;

            if (in_array($name, array_column($results, 'name')))
                continue;

            $shop_info = TextHelper::nl2br(trim(TextHelper::sanitizeHtml($value['shop_info'])));

            $result = array('name' => $name, 'shop_info' => $shop_info);
            $results[] = $result;
        }

        return $results;
    }

    public static function isShopInfoAvailable()
    {
        $merchants = GeneralConfig::getInstance()->option('merchants');
        if (!$merchants)
            return false;

        foreach ($merchants as $merchant)
        {
            if ($merchant['shop_info'])
                return true;
        }

        return false;
    }

}
