<?php defined('\ABSPATH') || exit; ?>
<div class="affpilot-rightcol">

    <?php if (\AffPilot\application\Plugin::isFree()): ?>

        <div class="affpilot-box" style="margin-top: 95px;">

            <div class="affpilot-box-container">
                <img src="<?php echo \AffPilot\PLUGIN_RES; ?>/img/external-importer-pro.jpg" alt="Avatar" class="affpilot-box-image">
                <a target="_blank" href="https://www.youtube.com/watch?v=GiUZF1U3bYM" class="affpilot-box-icon" title="User Profile">
                    <span class="dashicons dashicons-video-alt3"></span>
                </a>
            </div>               

            <h2 style="color:#8A2BE2 !important;">External Importer <span class="affpilot-box-label">New</span></h2>
            <p>Automated Import from a Website into WooCommerce.</p>
            <ul>
                <li>No API access required</li>
                <li>No work with CSV data feeds</li>
            </ul>
            <p>
                <a target="_blank" class="button-affpilot-banner" href="https://www.keywordrush.com/externalimporter?utm_source=cegg&utm_medium=referral&utm_campaign=plugin">View...</a>
            </p>


        </div>    
    <?php endif; ?>


    <?php
    /*
      <?php if (\AffPilot\application\Plugin::isFree()): ?>
      <div class="affpilot-box" style="margin-top: 95px;">
      <h2><?php _e('Maximum profit with minimum efforts', 'affpilot'); ?></h2>

      <a href="<?php echo AffPilot\application\Plugin::pluginSiteUrl(); ?>">
      <img src="<?php echo AffPilot\PLUGIN_RES; ?>/img/ce_pro_header.png" class="affpilot-imgcenter" />
      </a>

      <a href="<?php echo AffPilot\application\Plugin::pluginSiteUrl(); ?>">
      <img src="<?php echo AffPilot\PLUGIN_RES; ?>/img/ce_pro_coupon.png" class="affpilot-imgcenter" />
      </a>

      <h4><?php _e('Many additional modules and extended functions.', 'affpilot'); ?></h4>
      <p>
      <a target="_blank" class="button-affpilot-banner" href="<?php echo AffPilot\application\Plugin::pluginSiteUrl(); ?>">Get it now!</a>
      </p>
      </div>

     *
     */
    ?>

    <?php /*
      <div class="affpilot-box" style="margin-top: 15px;">
      <?php _e('Thank you for using Affpilot!', 'affpilot'); ?><br>
      <?php _e('If you have a moment, please leave a <a href="https://wordpress.org/support/plugin/affpilot/reviews/?rate=5#new-post>review</a>', 'affpilot'); ?>
      </div>
     * 
     */
    ?>
    <?php // endif; ?>


    <?php if (\AffPilot\application\Plugin::isEnvato()): ?>
        <div class="affpilot-box" style="margin-top: 95px;">
            <h2><?php _e('Activate plugin', 'affpilot'); ?></h2>
            <p><?php _e('In order to receive all benefits of Contennt Egg, you need to activate your copy of the plugin.', 'affpilot'); ?></p>
            <p><?php _e('By activating Contennt Egg license you will unlock premium options - direct plugin updates, access to user panel and official support.', 'affpilot'); ?></p>
            <p>
                <a class="button-affpilot-banner" href="<?php echo \get_admin_url(\get_current_blog_id(), 'admin.php?page=affpilot-lic'); ?>"><?php _e('Go to ', 'affpilot'); ?></a>
            </p>
        </div>
    <?php endif; ?>
</div>
