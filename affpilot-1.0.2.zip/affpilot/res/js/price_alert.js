jQuery(document).ready(function ()
{

    jQuery(".affpilot-price-alert-wrap form :input").each(function () {

        jQuery(this).on('input', function () {
            var $form = jQuery(this);
            var $wrap = $form.closest('.affpilot-price-alert-wrap');
            var $agree = $wrap.find('.price-alert-agree-wrap');
            var $email = $wrap.find('input[name="email"]');
            if ($email.val().length > 3 && $agree.is(":hidden"))
                $agree.show(500);
        });
    });

    jQuery(".affpilot-price-alert-wrap form").on("submit", function (event)
    {
        event.preventDefault();
        var $form = jQuery(this);
        var $wrap = $form.closest('.affpilot-price-alert-wrap');
        var data = $form.serialize() + '&nonce=' + ceggPriceAlert.nonce;
        $wrap.find('.affpilot-price-loading-image').show();
        $wrap.find('.affpilot-price-alert-result-error').hide();
        $form.find('input, button').prop("disabled", true);
        jQuery.ajax({
            url: ceggPriceAlert.ajaxurl + '?action=start_tracking',
            type: 'post',
            dataType: 'json',
            data: data,
            success: function (result) {
                if (result.status == 'success')
                {
                    $wrap.find('.affpilot-price-alert-result-succcess').show();
                    $wrap.find('.affpilot-price-alert-result-succcess').html(result.message);
                    $wrap.find('.affpilot-price-loading-image').hide();
                } else {
                    $form.find('input, button').prop("disabled", false);
                    $wrap.find('.affpilot-price-alert-result-error').show();
                    $wrap.find('.affpilot-price-alert-result-error').html(result.message);
                    $wrap.find('.affpilot-price-loading-image').hide();
                }
            }
        });

    });
});
