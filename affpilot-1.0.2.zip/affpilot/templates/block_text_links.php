<?php
/*
 * Name: Text links
 * Modules:
 * Module Types: PRODUCT
 * 
 */

use AffPilot\application\helpers\TemplateHelper;

if (!$all_items = TemplateHelper::sortAllByPrice($data, $order))
    return;

if (TemplateHelper::isModuleDataExist($all_items, 'Amazon', 'AmazonNoApi'))
    \wp_enqueue_script('affpilot-frontend', \AffPilot\PLUGIN_RES . '/js/frontend.js', array('jquery'));

$amazon_last_updated = TemplateHelper::getLastUpdateFormattedAmazon($data);
?>


<div class="affpilot-container affpilot-price-text-links">
    <ul>
        <?php foreach ($all_items as $key => $item): ?>    
            <li>
                <a<?php TemplateHelper::printRel(); ?> target="_blank" href="<?php echo $item['url']; ?>"><?php echo \esc_html(TemplateHelper::truncate($item['title'], 80)); ?></a>
                &mdash;
                <?php if ($item['price']): ?>
                    <b><?php echo TemplateHelper::formatPriceCurrency($item['price'], $item['currencyCode']); ?></b>
                <?php endif; ?> 
                <?php if ($item['priceOld']): ?>
                <strike class="text-muted"><?php echo TemplateHelper::formatPriceCurrency($item['priceOld'], $item['currencyCode']); ?></strike>
            <?php endif; ?>
            </li>
        <?php endforeach; ?>  
    </ul>

    <?php if ($amazon_last_updated): ?>
        <div class="affpilot-font60 affpilot-lineheight15 text-right">
            <?php echo sprintf(TemplateHelper::__('Last Amazon price update was: %s'), $amazon_last_updated); ?>
            <?php TemplateHelper::printAmazonDisclaimer(); ?>
        </div>
    <?php endif; ?>                     

</div>