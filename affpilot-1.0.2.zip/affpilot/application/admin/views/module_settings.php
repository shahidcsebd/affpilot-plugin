<?php defined('\ABSPATH') || exit; ?>

<?php if (\AffPilot\application\Plugin::isFree() || \AffPilot\application\Plugin::isInactiveEnvato()): ?>
    <div class="affpilot-maincol">
    <?php endif; ?>
    <div class="wrap">
        <h2>
            <?php _e('Module Settings', 'affpilot'); ?>
            <span class="affpilot-label affpilot-label-pro">pro <small><?php echo \AffPilot\application\Plugin::version(); ?></small></span>
        </h2>

        <h2 class="nav-tab-wrapper">
            <a href="?page=affpilot-modules" class="nav-tab<?php if (!empty($_GET['page']) && $_GET['page'] == 'affpilot-modules') echo ' nav-tab-active'; ?>">
                <span class="dashicons dashicons-menu-alt3"></span>
            </a>
            <?php foreach (AffPilot\application\components\ModuleManager::getInstance()->getConfigurableModules(true) as $m): ?>
                <?php if ($m->isDeprecated() && !$m->isActive()) continue; ?>
                <?php $c = $m->getConfigInstance(); ?>
                <a href="?page=<?php echo \esc_attr($c->page_slug()); ?>" class="nav-tab<?php if (!empty($_GET['page']) && $_GET['page'] == $c->page_slug()) echo ' nav-tab-active'; ?>">
                    <span<?php if ($m->isDeprecated()): ?> style="color: darkgray;"<?php endif; ?>>
                        <?php echo \esc_html($m->getName()); ?>                    
                    </span>
                </a>
            <?php endforeach; ?>
        </h2> 

        <div class="affpilot-wrap">
            <div class="affpilot-maincol">

                <h3>
                    <?php if ($module->isFeedParser() && !$module->isActive()): ?>
                        <?php _e('Add new feed module', 'affpilot'); ?>
                    <?php else: ?>
                        <?php echo \esc_html(sprintf(__('%s Settings', 'affpilot'), $module->getName())); ?>
                    <?php endif; ?>
                    <?php if ($docs_uri = $module->getDocsUri()) echo sprintf('<a target="_blank" class="page-title-action" href="%s">' . __('Documentation', 'affpilot') . '</a>', $docs_uri); ?>
                </h3>

                <?php if ($module->isDeprecated()): ?>
                    <div class="affpilot-warning">

                        <?php if ($module->getId() == 'Amazon'): ?>
                            <?php echo __('WARNING:', 'affpilot'); ?>
                            <?php echo sprintf(__('Amazon PA-API v4 <a target="_blank" href="%s"> is deprecated</a>.', 'affpilot'), 'https://webservices.amazon.com/paapi5/documentation/faq.html'); ?>
                            <?php echo sprintf(__('Only <a target="_blank" href="%s">Affpilot Pro</a> has support for the new PA-API v5.', 'affpilot'), 'https://www.keywordrush.com/affpilot/pricing'); ?>
                            <?php echo _e('Please', 'affpilot'); ?> <a target="_blank" href="https://ce-docs.keywordrush.com/modules/affiliate/amazon#why-amazon-module-is-not-available-in-ce-free-version"><?php _e('read more...', 'affpilot'); ?></a>
                        <?php endif; ?>

                        <?php if ($module->getId() != 'Amazon'): ?>
                            <strong>
                                <?php echo __('WARNING:', 'affpilot'); ?>
                                <?php echo __('This module is deprecated', 'affpilot'); ?>
                                (<a target="_blank" href="<?php echo \AffPilot\application\Plugin::pluginDocsUrl(); ?>/modules/deprecatedmodules"><?php _e('what does this mean', 'affpilot'); ?></a>).
                            </strong>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($module) && $requirements = $module->requirements()): ?>
                    <div class="affpilot-warning">  
                        <strong>
                            <?php echo _e('WARNING:', 'affpilot'); ?>
                            <?php _e('This module cannot be activated!', 'affpilot') ?>
                            <?php _e('Please fix the following error(s):', 'affpilot') ?>
                            <ul>
                                <li><?php echo join('</li><li>', $requirements) ?></li>
                            </ul>

                        </strong>
                    </div>
                <?php endif; ?>                            

                <?php \settings_errors(); ?>   
                <form action="options.php" method="POST">
                    <?php \settings_fields($config->page_slug()); ?>
                    <table class="form-table">
                        <?php \do_settings_sections($config->page_slug()); ?>								
                    </table>        
                    <?php \submit_button(); ?>
                </form>

            </div>

            <div class="affpilot-rightcol">
                <div>
                    <?php
                    if (!empty($description))
                        echo '<p>' . $description . '</p>';
                    ?>

                    <?php if (!empty($module) && $module->isFeedModule()): ?>
                        <?php if ($last_date = $module->getLastImportDateReadable()): ?>
                            <?php $prod_count = $module->getProductCount(); ?>
                            <li><?php echo sprintf(__('Last feed import: %s.', 'affpilot'), $last_date); ?></li>
                            <li><?php echo sprintf(__('Total products: %d.', 'affpilot'), $prod_count); ?></li>
                        <?php endif; ?>
                        <li title="<?php echo \esc_attr(__('Your unzipped feed must be smaller than this.', 'affpilot')); ?>"><?php echo sprintf(__('WordPress memory limit: %s', 'affpilot'), \WP_MAX_MEMORY_LIMIT); ?>
                            (<a href="https://wordpress.org/support/article/editing-wp-config-php/#increasing-memory-allocated-to-php" target="_blank">?</a>)
                        </li>                                        
                        <?php if ($last_error = $module->getLastImportError()): ?>
                            <li style="color: red;"><?php echo sprintf(__('Last error: %s', 'affpilot'), $last_error); ?></li>
                        <?php endif; ?>    

                        <?php if ($last_date && $prod_count): ?>
                            <hr /><br />
                            <div><a target="_blank" class="page-title-action" href="<?php echo \get_admin_url(\get_current_blog_id(), 'admin.php?page=affpilot-tools&action=feed-export&field=url&module=' . urlencode($module->getId())); ?>"><?php _e('Export product URLs', 'affpilot') ?></a></div>
                            <br />
                            <div><a target="_blank" class="page-title-action" href="<?php echo \get_admin_url(\get_current_blog_id(), 'admin.php?page=affpilot-tools&action=feed-export&field=ean&module=' . urlencode($module->getId())); ?>"><?php _e('Export product EANs', 'affpilot') ?></a></div>
                            <br />
                            <div><a target="_blank" class="page-title-action" href="<?php echo \get_admin_url(\get_current_blog_id(), 'admin.php?page=affpilot-tools&action=feed-export&field=ean_dublicate&module=' . urlencode($module->getId())); ?>"><?php _e('Export duplicate EANs', 'affpilot') ?></a></div>
                        <?php endif; ?>

                    <?php endif; ?>

                </div>
            </div>
        </div>


    </div>


    <?php if (\AffPilot\application\Plugin::isFree() || \AffPilot\application\Plugin::isInactiveEnvato()): ?>
    </div>    
    <?php include('_promo_box.php'); ?>
<?php endif; ?>