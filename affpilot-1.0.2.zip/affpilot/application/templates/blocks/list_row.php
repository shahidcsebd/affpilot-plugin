<?php
defined( '\ABSPATH' ) || exit;

use AffPilot\application\helpers\TemplateHelper;


?>

<!--<div class="affpilot-list-logo-title affpilot-mt5 affpilot-mb15 visible-xs text-center">-->
<!--    -->
<!--</div>-->

<div class="row-products">
    <div class="col-md-3 col-sm-3 col-xs-12 affpilot-title-cell text-center ">
        <span class="serial"><?php echo $serial; ?></span>
    </div>
    <div class="col-md-1 col-sm-1 col-xs-12 affpilot-image-cell">
		<?php if ( $item['img'] ): ?>
            <a<?php TemplateHelper::printRel(); ?> target="_blank" href="<?php echo $item['url']; ?>">
				<?php TemplateHelper::displayImage( $item, 130, 100 ); ?>
            </a>
		<?php endif; ?>
    </div>
    <div class="col-md-3 col-sm-3 col-xs-12 affpilot-desc-cell hidden-xs">
        <div class="affpilot-no-top-margin affpilot-list-logo-title">
            <a<?php TemplateHelper::printRel(); ?> target="_blank" href="<?php echo $item['url']; ?>"><?php echo esc_html( TemplateHelper::truncate( $item['title'], 100 ) ); ?></a>
        </div>

    </div>
    <div class="col-md-2 col-sm-2 col-xs-12 affpilot-btn-cell">
        <div class="affpilot-btn-row">
            <a<?php TemplateHelper::printRel(); ?> target="_blank" href="<?php echo $item['url']; ?>" class="btn btn-danger btn-block"><span><?php TemplateHelper::buyNowBtnText( true, $item, $btn_text ); ?></span></a>
        </div>
		<?php if ( $merchant = TemplateHelper::getMerchantName( $item ) ): ?>
            <div class="text-center">
                <small class="text-muted title-case">
					<?php echo \esc_html( $merchant ); ?>
					<?php TemplateHelper::printShopInfo( $item ); ?>
                </small>
            </div>
		<?php endif; ?>


    </div>
</div>

