<?php

namespace AffPilot\application\modules\Youtube;

defined('\ABSPATH') || exit;

use AffPilot\application\components\ParserModuleConfig;

/**
 * YoutubeConfig class file
 *
 * @author keywordrush.com <support@keywordrush.com>
 * @link http://www.keywordrush.com/
 * @copyright Copyright &copy; 2015 keywordrush.com
 */
class YoutubeConfig extends ParserModuleConfig {

    public function options()
    {
        $optiosn = array(
            'api_key' => array(
                'title' => 'API Key <span class="cegg_required">*</span>',
                'description' => __('API access key. You can get in Google <a href="http://code.google.com/apis/console">API console</a>.', 'affpilot'),
                'callback' => array($this, 'render_input'),
                'default' => '',
                'validator' => array(
                    'trim',
                    array(
                        'call' => array('\AffPilot\application\helpers\FormValidator', 'required'),
                        'when' => 'is_active',
                        'message' => __('The "API Key" can not be empty', 'affpilot'),
                    ),
                ),
                'section' => 'default',
            ),
            'entries_per_page' => array(
                'title' => __('Results', 'affpilot'),
                'description' => __('Number of results for a single query', 'affpilot'),
                'callback' => array($this, 'render_input'),
                'default' => '5',
                'validator' => array(
                    'trim',
                    'absint',
                ),
                'section' => 'default',
            ),
            'entries_per_page_update' => array(
                'title' => __('Results for blogging automation ', 'affpilot'),
                'description' => __('Number of results for blogging automation.', 'affpilot'),
                'callback' => array($this, 'render_input'),
                'default' => 3,
                'validator' => array(
                    'trim',
                    'absint',
                ),
                'section' => 'default',
            ),
            'order' => array(
                'title' => __('Sorting', 'affpilot'),
                'description' => '',
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => array(
                    'date' => __('Date', 'affpilot'),
                    'rating' => __('Rating', 'affpilot'),
                    'relevance' => __('Relevance', 'affpilot'),
                    'title' => __('Title', 'affpilot'),
                    'viewCount' => __('Views', 'affpilot'),
                ),
                'default' => 'relevance',
                'section' => 'default',
                'metaboxInit' => true,
            ),
            'license' => array(
                'title' => __('Type of license', 'affpilot'),
                'description' => __('Many videos on Youtube have Creative Commons license. <a href="http://www.google.com/support/youtube/bin/answer.py?answer=1284989">Know more</a>.', 'affpilot'),
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => array(
                    'any' => __('Any license', 'affpilot'),
                    'creativeCommon' => __('Creative Commons license', 'affpilot'),
                    'youtube' => __('Standard license', 'affpilot'),
                ),
                'default' => 'any',
                'section' => 'default',
                'metaboxInit' => true,
            ),
            'description_size' => array(
                'title' => __('Trim description', 'affpilot'),
                'description' => __('Description size in characters (0 - do not cut)', 'affpilot'),
                'callback' => array($this, 'render_input'),
                'default' => '280',
                'validator' => array(
                    'trim',
                    'absint',
                ),
                'section' => 'default',
            ),
        );
        $parent = parent::options();
        return array_merge($parent, $optiosn);
    }

}
