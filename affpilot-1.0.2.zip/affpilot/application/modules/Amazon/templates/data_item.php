<?php

defined('\ABSPATH') || exit;

/*
  Name: Product card
 */

__('Product card', 'affpilot-tpl');
$this->renderPartial('item');
