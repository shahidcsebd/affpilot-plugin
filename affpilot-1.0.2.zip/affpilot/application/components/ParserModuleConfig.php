<?php

namespace AffPilot\application\components;

defined('\ABSPATH') || exit;

/**
 * ParserModuleConfig abstract class file
 *
 * @author keywordrush.com <support@keywordrush.com>
 * @link http://www.keywordrush.com/
 * @copyright Copyright &copy; 2015 keywordrush.com
 */
abstract class ParserModuleConfig extends ModuleConfig {

    public function options()
    {
        $tpl_manager = ModuleTemplateManager::getInstance($this->module_id);
        $options = array(
            'is_active' => array(
                'title' => __('Enable Marketplace', 'affpilot'),
                'description' => '',
                'callback' => array($this, 'render_checkbox'),
                'default' => 0,
                'section' => 'default',
                'validator' => array(
                    array(
                        'call' => array($this, 'checkRequirements'),
                        'message' => __('Could not activate.', 'affpilot'),
                    ),
                ),
            ),
            'embed_at' => array(
                'title' => __('Listing Position', 'affpilot'),
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => array(
                    'shortcode' => __('Shortcodes only', 'affpilot'),
                    'post_bottom' => __('At the end of the post', 'affpilot'),
                    'post_top' => __('At the beginning of the post', 'affpilot'),
                ),
                'default' => 'shortcode',
                'section' => 'default',
            ),
            'priority' => array(
                'title' => __('Priority', 'affpilot'),
                'description' => __('Priority sets order of modules in post. 0 - is the most highest priority.', 'affpilot') . ' ' .
                __('Also it applied to price sorting.', 'affpilot'),
                'callback' => array($this, 'render_input'),
                'default' => 10,
                'validator' => array(
                    'trim',
                    'absint',
                ),
                'section' => 'default',
            ),
            'template' => array(
                'title' => __('Type of Table', 'affpilot'),
                'description' => __('Default template', 'affpilot'),
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => $tpl_manager->getTemplatesList(),
                'default' => $this->getModuleInstance()->defaultTemplateName(),
                'section' => 'default',
            ),
//            'tpl_title' => array(
//                'title' => __('Title', 'affpilot'),
//                'description' => __('Templates may use title on data output.', 'affpilot'),
//                'callback' => array($this, 'render_input'),
//                'default' => '',
//                'validator' => array(
//                    'trim',
//                ),
//                'section' => 'default',
//            ),
            'featured_image' => array(
                'title' => 'Featured image',
                'description' => __('Automatically set Featured image for post', 'affpilot'),
                'callback' => array($this, 'render_dropdown'),
                'dropdown_options' => array(
                    '' => __('Don\'t set', 'affpilot'),
                    'first' => __('First image', 'affpilot'),
                    'second' => __('Second image', 'affpilot'),
                    'rand' => __('Random image', 'affpilot'),
                    'last' => __('Last image', 'affpilot'),
                ),
                'default' => '',
                'section' => 'default',
            ),
            'set_local_redirect' => array(
                'title' => __('Redirect', 'affpilot'),
                'description' => __('Make links with local 301 redirect', 'affpilot'),
                'callback' => array($this, 'render_checkbox'),
                'default' => 0,
                'section' => 'default',
            ),
        );

        return array_merge(parent::options(), $options);
    }
    
    public function checkRequirements($value)
    {
        if ($requirements = $this->getModuleInstance()->requirements())
            return false;
        else
            return true;
    }

    protected static function moveRequiredUp(array $options)
    {
        $keys = array('is_active');

        foreach ($options as $key => $option)
        {
            if (strpos($option['title'], '*'))
                $keys[] = $key;
            
            $options[$key]['title'] = str_replace('**', '', $option['title']);
        }

        $res = array();
        foreach ($keys as $key)
        {
            $res[$key] = $options[$key];
            unset($options[$key]);
        }

        $res = array_merge($res, $options);
        return $res;
    }

}
