<?php
/*
 * Name: List
 * 
 */

use AffPilot\application\helpers\TemplateHelper;
?>


<div class="affpilot-container affpilot-list-withlogos affpilot-list-wdgt">

    <div class="affpilot-listcontainer">

        <?php foreach ($items as $key => $item): ?>           

            <div class="affpilot-list-logo-title affpilot-mb5 affpilot-mt10<?php if ($is_shortcode) echo ' visible-xs';?> text-center">
                <a<?php TemplateHelper::printRel(); ?> target="_blank" href="<?php echo $item['url']; ?>"><?php echo esc_html(TemplateHelper::truncate($item['title'], 100)); ?></a>
            </div>
        
            <div class="row-products"<?php if (!$is_shortcode) echo ' style="display:flex;"';?>>
                <div class="<?php if ($is_shortcode) echo 'col-md-2 col-sm-2 ';?>col-xs-12 affpilot-image-cell">

                    <div class="affpilot-position-container2">
                        <span class="affpilot-position-text2"><?php echo (int) $key + 1; ?></span>
                    </div>                    

                    <?php if ($item['img']): ?>
                        <a<?php TemplateHelper::printRel(); ?> target="_blank" href="<?php echo $item['url']; ?>"><img<?php if (!$is_shortcode) echo ' style="max-height: 70px;"'; ?> src="<?php echo $item['img']; ?>" alt="<?php echo \esc_attr($item['title']); ?>" /></a>
                    <?php endif; ?>
                </div>
                <?php if ($is_shortcode): ?>
                <div class="<?php if ($is_shortcode) echo 'col-md-5 col-sm-5 ';?>col-xs-12 affpilot-desc-cell hidden-xs">
                    <div class="affpilot-no-top-margin affpilot-list-logo-title">
                        <a<?php TemplateHelper::printRel(); ?> target="_blank" href="<?php echo $item['url']; ?>"><?php echo esc_html(TemplateHelper::truncate($item['title'], 100)); ?></a>
                    </div>
                </div>
                <?php endif; ?>
                <div class="<?php if ($is_shortcode) echo 'col-md-3 col-sm-3 ';?>col-xs-12 affpilot-price-cell text-center">
                    <div class="affpilot-price-row">

                        <?php if ($item['_price_movers']['discount_value']): ?>
                            <div class="text-muted"><strike title="<?php echo \esc_attr(TemplateHelper::getDaysAgo($item['_price_movers']['price_old_date']));?>"><?php echo TemplateHelper::formatPriceCurrency($item['_price_movers']['price_old'], $item['currencyCode']); ?></strike></div>
                        <?php endif; ?>

                        <?php if ($item['price']): ?>
                            
                            <div title="<?php echo \esc_attr(sprintf(TemplateHelper::__('as of %s'), TemplateHelper::dateFormatFromGmt($item['last_update']))); ?>" class="affpilot-price affpilot-price-color affpilot-price-<?php echo \esc_attr(TemplateHelper::getStockStatusClass($item)); ?>"><?php echo TemplateHelper::formatPriceCurrency($item['price'], $item['currencyCode']); ?></div>
                            
                            <?php if ($item['_price_movers']['discount_value'] > 0): ?>
                                <span class="text-success">
                                    &#9660;<?php echo TemplateHelper::formatPriceCurrency($item['_price_movers']['discount_value'], $item['currencyCode']); ?>
                                </span>
                            <?php endif; ?>                        
                        <?php endif; ?> 

                    </div> 
                </div>                    
                <div class="<?php if ($is_shortcode) echo 'col-md-2 col-sm-2 ';?>col-xs-12 affpilot-btn-cell">    
                    
                    <?php if ($item['_price_movers']['discount_percent'] > 0): ?>
                    <div class="text-center product-discount-off"><?php echo $item['_price_movers']['discount_percent']; ?>% <?php TemplateHelper::_e('OFF'); ?></div>
                    <?php endif; ?>                    
                    
                    <div class="affpilot-btn-row">
                        <a<?php TemplateHelper::printRel(); ?> target="_blank" href="<?php echo $item['url']; ?>" class="btn btn-danger btn-block<?php if(!$is_shortcode) echo ' btn-sm';?>"><span><?php TemplateHelper::buyNowBtnText(true, $item, $btn_text); ?></span></a> 
                    </div>  
                    <?php if ($merchant = TemplateHelper::getMerhantName($item)): ?>
                        <div class="text-center " style="margin: 0px; padding: 0px;">
                            <small class="text-muted title-case"><?php echo \esc_html($merchant); ?></small>
                        </div>
                    <?php endif; ?>

                </div>
            </div>

        <?php endforeach; ?>

    </div>
</div>

